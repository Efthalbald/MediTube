/**
 * MediTube dashboard script.
 *
 * Sections:
 *   1. State
 *   2. Small helpers
 *   3. Server sync (api/admin_schedule.php)
 *   4. Rendering
 *   5. Navigation
 *   6. Add / edit medication
 *   7. Dose history (filter + CSV export)
 *   8. Camera preview + recording (api/recordings.php)
 *   9. Device status and misc buttons
 *  10. Startup
 */

// ===========================================================================
// 1. State
// ===========================================================================

const COMPARTMENT_COLORS = ['blue', 'green', 'purple'];

// Everything on screen comes from the database. Nothing is seeded locally.
let doses = [];
let dataState = 'loading'; // 'loading' | 'ready' | 'error'
let lastSyncedAt = null;

// Dose history comes from api/dose_history.php (table dose_events).
let historyEvents = [];
let historyStats = null;
let historyState = 'loading'; // 'loading' | 'ready' | 'error'

// Device status comes from api/device_status.php (table device_telemetry).
let device = null;
let deviceState = 'loading'; // 'loading' | 'ready' | 'error'

// ===========================================================================
// 2. Small helpers
// ===========================================================================

const $ = (selector) => document.querySelector(selector);
const $$ = (selector) => [...document.querySelectorAll(selector)];

/** Escape text before putting it inside an HTML string. */
function esc(value) {
  const entities = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };

  return String(value).replace(/[&<>"']/g, (char) => entities[char]);
}

/** "13:05" -> "1:05 PM" */
function timeLabel(time) {
  const [hours, minutes] = time.split(':').map(Number);
  const hour12 = ((hours + 11) % 12) + 1;
  const suffix = hours >= 12 ? 'PM' : 'AM';

  return `${hour12}:${String(minutes).padStart(2, '0')} ${suffix}`;
}

function statusClass(status) {
  return status === 'Completed' ? '' : 'pending';
}

/** Show a short message at the bottom of the screen. */
function toast(message) {
  const element = $('#toast');

  element.textContent = message;
  element.classList.add('show');

  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => element.classList.remove('show'), 2600);
}

function csrfToken() {
  return $('meta[name=csrf-token]')?.content || '';
}

// ===========================================================================
// 3. Server sync
// ===========================================================================

/** Add one schedule row on the server. The list is then reloaded from the database. */
async function addScheduleToServer(dose) {
  const response = await fetch('api/admin_schedule.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': csrfToken(),
    },
    body: JSON.stringify({
      compartment: dose.compartment,
      medication_name: dose.name,
      dosage: dose.dosage,
      scheduled_time: dose.time + ':00',
    }),
  });

  if (!response.ok) {
    const result = await response.json().catch(() => ({}));
    throw new Error(result.error || 'Unable to save schedule');
  }
}

/** Record on the server that today's dose for this schedule row was taken. */
async function markCompleteOnServer(dose) {
  const response = await fetch('api/admin_schedule.php', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'X-CSRF-Token': csrfToken(),
    },
    body: JSON.stringify({ action: 'complete', schedule_id: dose.id }),
  });

  if (!response.ok) {
    const result = await response.json().catch(() => ({}));
    throw new Error(result.error || 'Unable to mark dose complete');
  }
}

/** Read the schedule from the database and redraw. Returns true when the read worked. */
async function loadScheduleFromServer() {
  try {
    const response = await fetch('api/admin_schedule.php', { cache: 'no-store' });
    const result = await response.json().catch(() => null);

    if (!response.ok || !result?.ok || !Array.isArray(result.schedule)) {
      throw new Error('Unexpected response from api/admin_schedule.php');
    }

    doses = result.schedule.map((row) => ({
      id: row.id,
      compartment: Number(row.compartment),
      name: row.medication_name,
      dosage: row.dosage,
      time: String(row.scheduled_time).slice(0, 5),
      color: COMPARTMENT_COLORS[Number(row.compartment) - 1] || 'blue',
      // Status comes from the database (completed today or not).
      status: row.status || 'Pending',
    }));
    dataState = 'ready';
    lastSyncedAt = new Date();
  } catch (error) {
    dataState = 'error';
  }

  renderAll();
  loadHistoryFromServer(); // keep the history in step with the schedule
  return dataState === 'ready';
}

/** Read dose history (real events + counts) from the database and redraw it. */
async function loadHistoryFromServer() {
  try {
    const response = await fetch('api/dose_history.php', { cache: 'no-store' });
    const result = await response.json().catch(() => null);

    if (!response.ok || !result?.ok || !Array.isArray(result.events)) {
      throw new Error('Unexpected response from api/dose_history.php');
    }

    historyEvents = result.events;
    historyStats = result.stats;
    historyState = 'ready';
  } catch (error) {
    historyState = 'error';
  }

  renderHistory();
  renderOverview(sortedByTime());
  return historyState === 'ready';
}

/** Read the newest ESP32 reading from the database and redraw every device area. */
async function loadDeviceStatus() {
  try {
    const response = await fetch('api/device_status.php', { cache: 'no-store' });
    const result = await response.json().catch(() => null);

    if (!response.ok || !result?.ok) throw new Error('Unexpected response from api/device_status.php');

    device = result;
    deviceState = 'ready';
  } catch (error) {
    deviceState = 'error';
  }

  renderDevice();
  return deviceState === 'ready';
}

function agoLabel(seconds) {
  if (seconds < 60) return `${seconds}s ago`;
  if (seconds < 3600) return `${Math.floor(seconds / 60)} min ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)} h ago`;

  return `${Math.floor(seconds / 86400)} d ago`;
}

function wifiQuality(rssi) {
  if (rssi >= -60) return 'Strong';
  if (rssi >= -70) return 'Good';
  if (rssi >= -80) return 'Fair';

  return 'Weak';
}

/** Overview widgets and the Device & connectivity page. Shows only what the device reported. */
function renderDevice() {
  const setText = (selector, text) => {
    $(selector).textContent = text;
  };
  const hasData = deviceState === 'ready' && device?.has_data === true;
  const online = hasData && device.online === true;
  const none = 'Not reported';

  // Status wording
  let pill = 'Checking…';
  if (deviceState === 'error') pill = 'Status unavailable';
  else if (deviceState === 'ready') pill = !hasData ? 'Waiting for device' : online ? 'Online' : 'Offline';

  const dotColor = online ? '' : deviceState === 'error' ? '#e5484d' : '#9ca3af';

  // Readings (only values the device actually sent)
  const percent = hasData ? device.battery_percent : null;
  const voltage = hasData ? device.battery_voltage : null;
  const rssi = hasData ? device.wifi_rssi : null;
  const firmware = hasData && device.firmware ? device.firmware : none;
  const batteryText = percent != null ? `${percent}%` : voltage != null ? `${voltage.toFixed(2)} V` : none;
  const wifiText = rssi != null ? `${wifiQuality(rssi)} (${rssi} dBm)` : none;
  const heartbeat = hasData ? `${agoLabel(device.seconds_ago)} · ${device.received_at}` : 'No heartbeat received';

  // Overview: device panel
  setText('#deviceOverviewPill', pill);
  setText('#devOverviewFirmware', `Firmware: ${hasData && device.firmware ? device.firmware : 'not reported'}`);
  setText('#devOverviewWifi', rssi != null ? `Wi-Fi: ${rssi} dBm` : 'Wi-Fi: not reported');
  setText('#devOverviewSignal', rssi != null ? wifiQuality(rssi) : none);
  setText('#heartbeat', heartbeat);

  // Overview: battery card
  setText('#devBatteryValue', percent != null ? `${percent}%` : voltage != null ? `${voltage.toFixed(2)} V` : '—');
  setText(
    '#devBatteryFoot',
    !hasData ? 'No device data yet' : online ? 'Reported by the device' : 'Last known value · device offline',
  );
  $('#devBatteryBar').style.width = percent != null ? `${Math.min(100, Math.max(0, percent))}%` : '0%';

  // Device page: connection card
  setText('#devicePillText', pill);
  $('#devicePillDot').style.background = dotColor;
  setText('#devConnection', pill);
  $('#devConnection').className = online ? 'green-text' : '';
  setText('#devFirmware', firmware);
  setText('#devBattery', batteryText);
  setText('#devWifi', wifiText);
  setText('#deviceHeartbeat', heartbeat);

  // Device page: telemetry
  setText('#telemetrySubtitle', hasData
    ? `Last reading ${device.received_at}${online ? '' : ' · device is offline'}`
    : 'Latest reading reported by the ESP32');
  setText('#telVoltage', voltage != null ? `${voltage.toFixed(2)} V` : '—');
  setText('#telVoltageNote', hasData ? (percent != null ? `${percent}% charge` : 'Reported by device') : 'No data yet');
  setText('#telRssi', rssi != null ? `${rssi} dBm` : '—');
  setText('#telRssiNote', rssi != null ? `${wifiQuality(rssi)} signal` : hasData ? none : 'No data yet');
  setText('#telDoor', hasData && device.door_state ? device.door_state : '—');
  setText('#telDoorNote', hasData ? (device.door_state ? 'Reported by device' : none) : 'No data yet');
  setText('#telMotor', hasData && device.motor_state ? device.motor_state : '—');
  setText('#telMotorNote', hasData ? (device.motor_state ? 'Reported by device' : none) : 'No data yet');
}

// ===========================================================================
// 4. Rendering
// ===========================================================================

function statusPill(dose, tag = 'span') {
  return `<${tag} class="status-pill ${statusClass(dose.status)}">${dose.status}</${tag}>`;
}

function doseRowHtml(dose) {
  return `
    <div class="dose-row">
      <div class="dose-color ${dose.color}">${String(dose.compartment).padStart(2, '0')}</div>
      <div class="dose-main">
        <b>${esc(dose.name)}</b>
        <small>Compartment ${dose.compartment} · ${esc(dose.dosage)}</small>
      </div>
      <div class="dose-time">
        <b>${timeLabel(dose.time)}</b>
        ${statusPill(dose, 'small')}
      </div>
    </div>`;
}

function scheduleTableHtml(sortedDoses) {
  // Completed doses leave this list; they stay visible in Dose history.
  const rows = sortedDoses
    .filter((dose) => dose.status !== 'Completed')
    .map((dose) => {
      return `
        <tr>
          <td><b>${esc(dose.name)}</b></td>
          <td>Compartment ${dose.compartment}</td>
          <td>${timeLabel(dose.time)}</td>
          <td>${esc(dose.dosage)}</td>
          <td>${statusPill(dose)}</td>
          <td><button class="table-action" data-edit="${dose.id}">Mark complete</button></td>
        </tr>`;
    })
    .join('');

  return `
    <table class="data-table">
      <thead>
        <tr>
          <th>MEDICATION</th><th>COMPARTMENT</th><th>TIME</th>
          <th>DOSAGE</th><th>STATUS</th><th>ACTION</th>
        </tr>
      </thead>
      <tbody>${
        rows ||
        `<tr><td colspan="6">${
          doses.length
            ? 'All of today\'s doses are completed. See them in Dose history.'
            : 'No medication scheduled yet.'
        }</td></tr>`
      }</tbody>
    </table>`;
}

function compartmentCardHtml(number) {
  // Same list as the Medication schedule page: only pending schedules, in time order.
  // Completed ones disappear here too and stay visible in Dose history.
  const inCompartment = doses
    .filter((item) => Number(item.compartment) === number && item.status !== 'Completed')
    .sort((a, b) => a.time.localeCompare(b.time));
  const color = inCompartment[0]?.color || COMPARTMENT_COLORS[number - 1];
  const count = inCompartment.length;
  const scheduleRows = inCompartment
    .map(
      (item) => `
        <div class="comp-schedule-row">
          <div>
            <b>${esc(item.name)}</b>
            <small>${esc(item.dosage)}</small>
          </div>
          <div class="comp-schedule-time">
            <b>${timeLabel(item.time)}</b>
            ${statusPill(item, 'small')}
          </div>
        </div>`,
    )
    .join('');
  const tubeClass = color === 'green' ? 'green-tube-art' : color === 'purple' ? 'purple-tube-art' : '';

  return `
    <div class="compartment-card">
      <div class="compartment-top">
        <span class="compartment-number ${color}">0${number}</span>
        <span class="connected-pill"><i></i> Locked</span>
      </div>
      <div class="compartment-art">
        <div class="tube-art ${tubeClass}"><span>0${number}</span></div>
      </div>
      <h3>Compartment ${number}</h3>
      <p>${count ? `${count} pending schedule${count === 1 ? '' : 's'}` : 'Nothing pending'}</p>
      <div class="comp-schedule-list">
        ${scheduleRows || '<div class="comp-schedule-empty">No sched for this compartment yet</div>'}
      </div>
      <div class="compartment-meta">
        <span>Motor lock</span><b class="green-text">Engaged</b>
      </div>
      <button class="btn btn-secondary lock-button" data-unlock="${number}">Simulate unlock</button>
    </div>`;
}

function activityItemHtml(event) {
  return `
    <div class="activity-item">
      <span class="activity-icon">${event.icon}</span>
      <div><b>${esc(event.title)}</b><small>${esc(event.detail)}</small></div>
      <span class="activity-time">${event.time}</span>
    </div>`;
}

/** "dose_completed" -> "Dose completed" */
function eventLabel(event) {
  const text = String(event.event_type).replace(/_/g, ' ');

  return text.charAt(0).toUpperCase() + text.slice(1);
}

/** Shape a database event for the "Recent activity" list on the overview. */
function activityFromEvent(event) {
  const medication = event.medication_name || 'Medication';

  return {
    icon: event.completed ? '✓' : '•',
    title: event.completed ? `${medication} marked complete` : `${eventLabel(event)}: ${medication}`,
    detail: `Compartment ${event.compartment} · ${event.source}`,
    time: event.time,
  };
}

function historyTableHtml() {
  const rows = historyEvents
    .map(
      (event) => `
        <tr data-status="${event.completed ? 'Completed' : 'Other'}">
          <td>${esc(event.date)} · ${esc(event.time)}</td>
          <td><b>${esc(event.medication_name || '—')}</b><br /><small class="muted">${esc(eventLabel(event))}</small></td>
          <td>${event.compartment}</td>
          <td>${
            event.completed
              ? '<span class="status-pill">Completed</span>'
              : `<span class="status-pill pending">${esc(eventLabel(event))}</span>`
          }</td>
          <td>${esc(event.source)}</td>
        </tr>`,
    )
    .join('');

  return `
    <table class="data-table">
      <thead>
        <tr>
          <th>DATE / TIME</th><th>EVENT</th><th>COMPARTMENT</th><th>STATUS</th><th>SOURCE</th>
        </tr>
      </thead>
      <tbody>${rows || `<tr><td colspan="5">${
        historyState === 'error' ? 'Dose history could not be loaded.' : historyState === 'loading' ? 'Loading…' : 'No dose events recorded yet.'
      }</td></tr>`}</tbody>
    </table>`;
}

/** Show or hide history rows according to the filter dropdown. */
function applyHistoryFilter() {
  const selected = $('#historyFilter').value;

  $$('#historyTable tbody tr[data-status]').forEach((row) => {
    row.style.display = selected === 'all' || row.dataset.status === selected ? '' : 'none';
  });
}

/** Dose history page: the table and summary cards come from the database. */
function renderHistory() {
  const ready = historyState === 'ready' && historyStats;
  const dash = '—';

  $('#historyTable').innerHTML = historyTableHtml();
  applyHistoryFilter();

  $('#histTotal').textContent = ready ? historyStats.total : dash;
  $('#histTotalFoot').textContent = ready ? 'All recorded events' : historyState === 'error' ? 'Database unavailable' : 'Loading…';
  $('#histDone').textContent = ready ? historyStats.completed : dash;
  $('#histDoneFoot').textContent = ready ? `${historyStats.completed_today} completed today` : dash;
  $('#histPending').textContent = ready ? historyStats.pending_today : dash;
  $('#histPendingFoot').textContent = ready ? 'Still to be completed today' : dash;
}

function sortedByTime() {
  return [...doses].sort((a, b) => a.time.localeCompare(b.time));
}

function minutesNow() {
  const now = new Date();
  return now.getHours() * 60 + now.getMinutes();
}

function minutesOf(time) {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
}

/** Doses still ahead today: not completed and later than the current time. */
function upcomingDoses(sortedDoses) {
  const now = minutesNow();
  return sortedDoses.filter((dose) => dose.status !== 'Completed' && minutesOf(dose.time) > now);
}

function countdownLabel(dose) {
  const diff = minutesOf(dose.time) - minutesNow();
  const pad = (n) => String(n).padStart(2, '0');

  return `${pad(Math.floor(diff / 60))}h ${pad(diff % 60)}m`;
}

function reminderList(sortedDoses) {
  if (dataState !== 'ready') return [];

  const [next] = upcomingDoses(sortedDoses);
  if (!next) return [];

  return [
    {
      icon: '◷',
      tone: 'amber-bg',
      title: 'Upcoming medication',
      text: `${next.name} is scheduled for ${timeLabel(next.time)}.`,
    },
  ];
}

function emptyHtml(text) {
  return `<p class="muted" style="padding: 16px">${esc(text)}</p>`;
}

function reminderHtml(reminder) {
  return `
    <div class="reminder">
      <span class="reminder-icon ${reminder.tone}">${reminder.icon}</span>
      <div><b>${esc(reminder.title)}</b><p>${esc(reminder.text)}</p></div>
    </div>`;
}

/** Overview page: every value is derived from the database schedule or left blank. */
function renderOverview(sortedDoses) {
  const ready = dataState === 'ready';
  const notice = dataState === 'error' ? 'Database unavailable' : 'Loading…';
  const total = sortedDoses.length;
  const completed = sortedDoses.filter((dose) => dose.status === 'Completed').length;
  const upcoming = upcomingDoses(sortedDoses);
  const next = upcoming[0];
  const dash = '—';

  // Header
  const now = new Date();
  const hour = now.getHours();
  const greeting = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening';
  const title = $('#greetingTitle');

  title.firstChild.textContent = `${greeting}, ${title.dataset.name} `;
  $('#todayLabel').textContent = now
    .toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' })
    .toUpperCase();

  // Next-dose card
  let heroTitle = notice;
  let heroDetail = dataState === 'error' ? 'The schedule could not be read from the database.' : '';
  let heroCountdown = '';
  let heroDosage = '';
  let heroNumber = '';

  if (ready && !total) {
    heroTitle = 'No medication scheduled';
    heroDetail = 'Add a medication on the Medication schedule page.';
  } else if (ready && !next) {
    heroTitle = 'No more doses today';
    heroDetail = 'Nothing else is scheduled for the rest of today.';
  } else if (ready) {
    heroTitle = `Your next dose is<br /><strong>${timeLabel(next.time)}</strong>`;
    heroDetail = `Compartment ${next.compartment} · ${esc(next.name)}`;
    heroCountdown = `◷ In <b id="countdown">${countdownLabel(next)}</b>`;
    heroDosage = `▣ ${esc(next.dosage)} scheduled`;
    heroNumber = String(next.compartment).padStart(2, '0');
  }

  $('#heroTitle').innerHTML = heroTitle;
  $('#heroDetail').innerHTML = heroDetail;
  $('#heroCountdown').innerHTML = heroCountdown;
  $('#heroDosage').innerHTML = heroDosage;
  $('#heroNumber').textContent = heroNumber;

  // Stat cards
  const compartmentsUsed = new Set(sortedDoses.map((dose) => dose.compartment)).size;

  $('#statTotal').innerHTML = ready ? `${total} <small>scheduled</small>` : dash;
  $('#statTotalFoot').textContent = ready
    ? total
      ? `${compartmentsUsed} of 3 compartments in use`
      : 'Nothing scheduled yet'
    : notice;
  $('#statDone').innerHTML = ready ? `${completed} <small>/ ${total}</small>` : dash;
  $('#statDoneFoot').textContent = ready
    ? total
      ? `${upcoming.length} upcoming today`
      : 'No doses to track'
    : notice;
  $('#statDoneBar').style.width = ready && total ? `${Math.round((completed / total) * 100)}%` : '0%';
  $('#statDb').textContent = ready ? 'Connected' : dataState === 'error' ? 'Unavailable' : 'Checking…';
  $('#lastSync').textContent = lastSyncedAt
    ? lastSyncedAt.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    : dash;

  // Lists
  // Completed doses leave this list; they stay visible in Dose history.
  const pendingDoses = sortedDoses.filter((dose) => dose.status !== 'Completed');

  $('#dashboardDoses').innerHTML = pendingDoses.length
    ? pendingDoses.map(doseRowHtml).join('')
    : emptyHtml(
        !ready
          ? notice
          : total
            ? 'All of today\'s doses are completed. See them in Dose history.'
            : 'No medication scheduled yet.',
      );
  $('#recentActivity').innerHTML = historyEvents.length
    ? historyEvents
        .slice(0, 5)
        .map((event) => activityItemHtml(activityFromEvent(event)))
        .join('')
    : emptyHtml(historyState === 'error' ? 'Activity could not be loaded.' : 'No activity recorded yet.');

  const reminders = reminderList(sortedDoses);

  $('#remindersCount').textContent = reminders.length;
  $('#careReminders').innerHTML = reminders.length
    ? reminders.map(reminderHtml).join('')
    : emptyHtml('No reminders right now.');

  // Schedule page badge
  const pendingCount = total - completed;

  $('#scheduleCount').textContent = ready
    ? `${pendingCount} pending schedule${pendingCount === 1 ? '' : 's'}`
    : dash;
}

/** Redraw every list/table that depends on `doses` or `events`. */
function renderAll() {
  const sortedDoses = sortedByTime();

  renderOverview(sortedDoses);
  $('#scheduleTable').innerHTML = scheduleTableHtml(sortedDoses);
  $('#compartmentCards').innerHTML = [1, 2, 3].map(compartmentCardHtml).join('');
  renderHistory();
}

// ===========================================================================
// 5. Navigation
// ===========================================================================

function go(page) {
  $$('.page').forEach((section) => {
    section.classList.toggle('active-page', section.id === `page-${page}`);
  });
  $$('.nav-link').forEach((link) => {
    link.classList.toggle('active', link.dataset.page === page);
  });

  const activeLink = $(`[data-page="${page}"]`);
  $('#crumb').textContent = activeLink
    ? activeLink.textContent.trim().replace(/\s+/g, ' ')
    : 'Overview';

  history.replaceState(null, '', `#${page}`);
  $('#sidebar').classList.remove('open');
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

$$('[data-page]').forEach((link) => {
  link.addEventListener('click', (event) => {
    event.preventDefault();
    go(link.dataset.page);
  });
});

$$('[data-go]').forEach((element) => {
  element.addEventListener('click', () => go(element.dataset.go));
});

$('#mobileMenu').addEventListener('click', () => {
  $('#sidebar').classList.toggle('open');
});

// ===========================================================================
// 6. Add / edit medication
// ===========================================================================

const doseModal = $('#doseModal');

function closeDoseModal() {
  doseModal.classList.remove('show');
}

$('#addDose').addEventListener('click', () => doseModal.classList.add('show'));

$$('[data-close]').forEach((button) => button.addEventListener('click', closeDoseModal));

// Clicking the dark backdrop (but not the modal itself) closes it.
doseModal.addEventListener('click', (event) => {
  if (event.target.id === 'doseModal') closeDoseModal();
});

$('#doseForm').addEventListener('submit', (event) => {
  event.preventDefault();

  const form = new FormData(event.target);
  const dose = {
    compartment: Number(form.get('compartment')),
    name: form.get('name'),
    dosage: form.get('dosage'),
    time: form.get('time'),
    color: form.get('color'),
  };

  addScheduleToServer(dose)
    .then(() => loadScheduleFromServer())
    .then((ok) => toast(ok ? 'Medication schedule saved to the database.' : 'Saved, but the list could not be reloaded.'))
    .catch((error) => toast(error.message));

  closeDoseModal();
  event.target.reset();
});

// "Mark complete" and "Simulate unlock" buttons are created dynamically,
// so one delegated click handler covers both.
document.addEventListener('click', (event) => {
  const completeButton = event.target.closest('[data-edit]');

  if (completeButton) {
    const dose = doses.find((item) => item.id == completeButton.dataset.edit);

    if (dose) {
      markCompleteOnServer(dose)
        .then(() => loadScheduleFromServer())
        .then((ok) => toast(ok ? 'Dose marked complete and saved to the database.' : 'Saved, but the list could not be reloaded.'))
        .catch((error) => toast(error.message));
    }
  }

  if (event.target.closest('[data-unlock]')) {
    toast(
      "Safety interlock: physical unlocking is not enabled in this release. Use the physical device's validated controls.",
    );
  }
});

// ===========================================================================
// 7. Dose history
// ===========================================================================

$('#historyFilter').addEventListener('change', applyHistoryFilter);

$('#exportHistory').addEventListener('click', () => {
  if (!historyEvents.length) {
    toast('There is no dose history to export yet.');
    return;
  }

  const header = ['Date', 'Time', 'Medication', 'Compartment', 'Event', 'Source'];
  const rows = historyEvents.map((event) => [
    event.date,
    event.time,
    event.medication_name || '',
    event.compartment,
    eventLabel(event),
    event.source,
  ]);

  // Quote every cell and double any quotes inside it.
  const csv = [header, ...rows]
    .map((row) => row.map((cell) => '"' + String(cell).replaceAll('"', '""') + '"').join(','))
    .join('\n');

  const link = document.createElement('a');
  link.href = URL.createObjectURL(new Blob([csv], { type: 'text/csv' }));
  link.download = 'meditube-dose-history.csv';
  link.click();
  URL.revokeObjectURL(link.href);
});

// ===========================================================================
// 8. Camera preview + recording (local browser camera, not the device camera)
// ===========================================================================

let mediaRecorder = null;
let recordedChunks = [];
let recordTicker = null;
let recordStartedAt = 0;

const recordingList = $('#recordingList');

// The record button is created here, next to "Stop preview".
const recordButton = document.createElement('button');
recordButton.type = 'button';
recordButton.className = 'btn btn-secondary';
recordButton.textContent = '● Start recording';
recordButton.hidden = true;
$('#stopCamera').after(recordButton);

function recorderMimeType() {
  const options = ['video/webm;codecs=vp9', 'video/webm;codecs=vp8', 'video/webm', 'video/mp4'];

  return options.find((type) => window.MediaRecorder && MediaRecorder.isTypeSupported(type)) || '';
}

function downloadBlob(blob, filename) {
  const link = document.createElement('a');

  link.href = URL.createObjectURL(blob);
  link.download = filename;
  link.click();
  setTimeout(() => URL.revokeObjectURL(link.href), 1000);
}

function formatBytes(bytes) {
  return bytes > 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(bytes / 1024))} KB`;
}

function recordingHtml(item) {
  const url = `api/recordings.php?file=${encodeURIComponent(item.file)}`;

  return `
    <div class="recording" data-play="${esc(url)}" style="cursor:pointer">
      <div class="record-thumb thumb-one">▷</div>
      <div>
        <b>${esc(item.time)}</b>
        <small>${esc(item.file)} · ${formatBytes(item.size)}</small>
      </div>
      <span class="video-state">Saved</span>
      <button type="button" class="table-action" data-delete="${esc(item.file)}" title="Delete this recording">🗑 Delete</button>
    </div>`;
}

/** Delete one recording from the server, then refresh the list. */
async function deleteRecording(file) {
  if (!confirm(`Delete ${file}? This cannot be undone.`)) return;

  try {
    const response = await fetch(`api/recordings.php?delete=${encodeURIComponent(file)}`, {
      method: 'POST',
      headers: { 'X-CSRF-Token': csrfToken() },
    });
    const result = await response.json().catch(() => ({}));

    if (!response.ok || !result.ok) throw new Error(result.error || 'Unable to delete recording');

    toast('Recording deleted.');
  } catch (error) {
    toast(error.message);
  }

  loadRecordings();
}

/** Fill the "Recent recordings" panel from the saved files on the server. */
async function loadRecordings() {
  const badge = $('#videoCount');

  try {
    const response = await fetch('api/recordings.php', { cache: 'no-store' });
    const result = await response.json();

    if (!response.ok || !result.ok) throw new Error();

    recordingList.innerHTML = result.recordings.length
      ? result.recordings.map(recordingHtml).join('')
      : '<div class="empty-video">No recordings yet. Start the camera preview, then press Start recording.</div>';

    badge.textContent = result.recordings.length;
    badge.hidden = result.recordings.length === 0;
  } catch (error) {
    recordingList.innerHTML = '<div class="empty-video">Could not load recordings.</div>';
    badge.hidden = true;
  }
}

// Click a recording to play it right under its row; click again to close.
recordingList.addEventListener('click', (event) => {
  const deleteButton = event.target.closest('[data-delete]');

  if (deleteButton) {
    event.stopPropagation();
    deleteRecording(deleteButton.dataset.delete);
    return;
  }

  const row = event.target.closest('[data-play]');
  if (!row) return;

  const open = row.nextElementSibling;
  recordingList.querySelectorAll('.inline-player').forEach((player) => player.remove());
  if (open?.classList.contains('inline-player')) return;

  const video = document.createElement('video');
  video.className = 'inline-player';
  video.src = row.dataset.play;
  video.controls = true;
  video.autoplay = true;
  video.playsInline = true;
  video.style.cssText = 'width:100%;border-radius:12px;margin:8px 0';
  row.after(video);
});

/** Auto-save: upload to the server, or download to this computer if that fails. */
async function saveRecording(blob) {
  if (!blob.size) {
    toast('The recording was empty, so nothing was saved.');
    return;
  }

  const baseType = blob.type.split(';')[0] || 'video/webm';
  const ext = baseType === 'video/mp4' ? 'mp4' : 'webm';
  toast('Saving recording…');

  try {
    const response = await fetch('api/recordings.php', {
      method: 'POST',
      headers: { 'Content-Type': baseType, 'X-CSRF-Token': csrfToken() },
      body: blob,
    });
    const result = await response.json().catch(() => ({}));

    if (!response.ok || !result.ok) throw new Error(result.error || 'Upload failed');

    toast(`Recording saved: ${result.file}`);
    loadRecordings();
  } catch (error) {
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');

    downloadBlob(blob, `meditube-${stamp}.${ext}`);
    toast(`${error.message}. Saved to your downloads instead.`);
  }
}

function startRecording(stream) {
  if (!window.MediaRecorder) {
    toast('Recording is not supported in this browser.');
    return;
  }

  const mimeType = recorderMimeType();

  recordedChunks = [];
  mediaRecorder = new MediaRecorder(stream, mimeType ? { mimeType } : undefined);

  mediaRecorder.ondataavailable = (event) => {
    if (event.data.size > 0) recordedChunks.push(event.data);
  };

  mediaRecorder.onstop = () => {
    const blob = new Blob(recordedChunks, { type: mediaRecorder?.mimeType || mimeType || 'video/webm' });

    recordedChunks = [];
    mediaRecorder = null;
    clearInterval(recordTicker);
    recordButton.textContent = '● Start recording';
    saveRecording(blob); // auto-save as soon as recording ends
  };

  mediaRecorder.start(1000);
  recordStartedAt = Date.now();
  recordTicker = setInterval(() => {
    const seconds = Math.floor((Date.now() - recordStartedAt) / 1000);
    const clock = `${String(Math.floor(seconds / 60)).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;

    recordButton.textContent = `■ Stop & save (${clock})`;
  }, 500);
  recordButton.textContent = '■ Stop & save (00:00)';
  toast('Recording started.');
}

function stopRecording() {
  if (mediaRecorder && mediaRecorder.state !== 'inactive') mediaRecorder.stop();
}

recordButton.addEventListener('click', () => {
  const video = $('#localVideo');

  if (mediaRecorder && mediaRecorder.state !== 'inactive') {
    stopRecording();
  } else if (video.srcObject) {
    startRecording(video.srcObject);
  }
});

$('#recordDemo').addEventListener('click', async () => {
  const video = $('#localVideo');

  if (!navigator.mediaDevices?.getUserMedia) {
    toast('Camera preview is not supported in this browser.');
    return;
  }

  try {
    const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: false });

    video.srcObject = stream;
    video.hidden = false;
    recordButton.hidden = false;
    $('.camera-view').style.display = 'none';
    $('#cameraStatus').textContent =
      'Local browser camera preview is active. This is not the device camera.';
    toast('Camera preview started.');
  } catch (error) {
    toast('Camera permission was denied or no camera was found.');
  }
});

$('#stopCamera').addEventListener('click', () => {
  const video = $('#localVideo');

  stopRecording(); // saves the recording if one is in progress

  if (video.srcObject) {
    video.srcObject.getTracks().forEach((track) => track.stop());
    video.srcObject = null;
  }

  video.hidden = true;
  recordButton.hidden = true;
  $('.camera-view').style.display = 'grid';
  $('#cameraStatus').textContent = 'Preview is simulated until a camera stream is connected.';
});

// Don't lose a recording if the tab is closed mid-recording.
window.addEventListener('beforeunload', (event) => {
  if (mediaRecorder && mediaRecorder.state !== 'inactive') {
    event.preventDefault();
    event.returnValue = '';
  }
});

// ===========================================================================
// 9. Device status and misc buttons
// ===========================================================================

$('#refreshDevice').addEventListener('click', async () => {
  const [scheduleOk, deviceOk] = await Promise.all([loadScheduleFromServer(), loadDeviceStatus()]);

  if (!scheduleOk || !deviceOk) {
    toast('Could not reach the database.');
  } else if (!device?.has_data) {
    toast('Refreshed. The ESP32 has not sent any data yet.');
  } else {
    toast(device.online ? 'Device status refreshed.' : 'Refreshed. The device is offline.');
  }
});

// Copy buttons: copy the text of another element...
$$('[data-copy]').forEach((button) => {
  button.addEventListener('click', () => {
    navigator.clipboard
      ?.writeText($('#' + button.dataset.copy).textContent)
      .then(() => toast('Copied to clipboard.'))
      .catch(() => toast('Copy unavailable in this browser.'));
  });
});

// ...or copy a literal value stored on the button itself.
$$('[data-copy-text]').forEach((button) => {
  button.addEventListener('click', () => {
    navigator.clipboard
      ?.writeText(button.dataset.copyText)
      .then(() => toast('Copied to clipboard.'));
  });
});

$('#notificationBtn').addEventListener('click', () => {
  const count = reminderList(sortedByTime()).length;

  toast(count ? `You have ${count} care reminder${count === 1 ? '' : 's'}.` : 'No care reminders right now.');
});

$('#inviteCaregiver').addEventListener('click', () => {
  toast('Caregiver invitation is a UI placeholder in this application.');
});

// ===========================================================================
// 10. Startup
// ===========================================================================

// Open the page named in the URL hash (e.g. index.php#history).
const startPage = location.hash.replace('#', '');
if (startPage && $(`#page-${startPage}`)) go(startPage);

// Show the real address of this server's API (the ESP32 must be able to reach it).
$('#apiUrl').textContent = new URL('api', location.href).href;

renderAll();
renderDevice();
loadScheduleFromServer();
loadRecordings();
loadDeviceStatus();

// Re-check the device every 15 seconds so Online / Offline stays accurate.
setInterval(loadDeviceStatus, 15000);

// Keep the countdown and "next dose" current without reloading.
setInterval(() => renderOverview(sortedByTime()), 30000);
