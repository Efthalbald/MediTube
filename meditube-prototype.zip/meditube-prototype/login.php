<?php

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

// Already signed in? Go straight to the dashboard.
if (!empty($_SESSION['user_id'])) {
    header('Location: index.php');
    exit;
}

// Role given to every self-registered account. Never let the form choose it.
const DEFAULT_SIGNUP_ROLE = 'caregiver';

// Set to 0 if an admin should approve new accounts before they can sign in.
const SIGNUP_AUTO_ACTIVE = 1;

// Pre-login CSRF token (the post-login one is created after sign in).
if (empty($_SESSION['guest_csrf'])) {
    $_SESSION['guest_csrf'] = bin2hex(random_bytes(32));
}

$mode      = (($_POST['action'] ?? $_GET['mode'] ?? '') === 'register') ? 'register' : 'login';
$error     = '';
$formName  = '';
$formEmail = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tokenOk = hash_equals($_SESSION['guest_csrf'], (string) ($_POST['csrf'] ?? ''));

    if (!$tokenOk) {
        $error = 'Your session expired. Please try again.';
    } elseif ($mode === 'register') {
        // ---------- CREATE ACCOUNT ----------
        $formName  = trim((string) ($_POST['full_name'] ?? ''));
        $formEmail = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password  = (string) ($_POST['password'] ?? '');
        $confirm   = (string) ($_POST['password_confirm'] ?? '');

        if (mb_strlen($formName) < 2 || mb_strlen($formName) > 100) {
            $error = 'Please enter your full name (2–100 characters).';
        } elseif (!filter_var($formEmail, FILTER_VALIDATE_EMAIL) || strlen($formEmail) > 190) {
            $error = 'Please enter a valid email address.';
        } elseif (strlen($password) < 8) {
            $error = 'Password must be at least 8 characters long.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } else {
            $check = $pdo->prepare('SELECT id FROM users WHERE email = ? LIMIT 1');
            $check->execute([$formEmail]);

            if ($check->fetch()) {
                $error = 'An account with that email already exists.';
            } else {
                try {
                    $insert = $pdo->prepare(
                        'INSERT INTO users (full_name, email, password_hash, role, active)
                         VALUES (?, ?, ?, ?, ?)'
                    );
                    $insert->execute([
                        $formName,
                        $formEmail,
                        password_hash($password, PASSWORD_DEFAULT),
                        DEFAULT_SIGNUP_ROLE,
                        SIGNUP_AUTO_ACTIVE,
                    ]);

                    audit_log($pdo, (int) $pdo->lastInsertId(), 'register', 'user');

                    header('Location: login.php?created=' . (SIGNUP_AUTO_ACTIVE ? '1' : 'pending'));
                    exit;
                } catch (PDOException $e) {
                    // 23000 = duplicate email slipped in between the check and the insert.
                    $error = $e->getCode() === '23000'
                        ? 'An account with that email already exists.'
                        : 'We could not create your account. Please try again.';
                }
            }
        }
    } else {
        // ---------- SIGN IN ----------
        $email    = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        $statement = $pdo->prepare(
            'SELECT id, full_name, email, password_hash, role, active
             FROM users
             WHERE email = ?
             LIMIT 1'
        );
        $statement->execute([$email]);
        $user = $statement->fetch();

        $credentialsValid = $user
            && (int) $user['active'] === 1
            && password_verify($password, $user['password_hash']);

        if ($credentialsValid) {
            // New session id on login prevents session fixation.
            session_regenerate_id(true);

            $_SESSION['user_id']   = $user['id'];
            $_SESSION['user_name'] = $user['full_name'];
            $_SESSION['user_role'] = $user['role'];
            $_SESSION['csrf']      = bin2hex(random_bytes(32));
            unset($_SESSION['guest_csrf']);

            $pdo->prepare('UPDATE users SET last_login_at = NOW() WHERE id = ?')
                ->execute([$user['id']]);

            audit_log($pdo, (int) $user['id'], 'login', 'session');

            header('Location: index.php');
            exit;
        }

        $error = 'Email or password is incorrect, or the account is disabled.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $mode === 'register' ? 'Create account' : 'Sign in' ?> · MediTube</title>
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/login.css">
</head>
<body>
    <main class="login-card">
        <div class="login-brand">◉ MediTube</div>

        <?php if ($mode === 'register'): ?>
            <h1>Create your account</h1>
            <p>Register to start managing medication care.</p>
        <?php else: ?>
            <h1>Welcome back</h1>
            <p>Sign in to manage medication care.</p>
        <?php endif; ?>

        <?php if (isset($_GET['installed'])): ?>
            <p class="login-error login-success">
                Administrator created. Sign in below, then delete install.php.
            </p>
        <?php endif; ?>

        <?php if (($_GET['created'] ?? '') === '1'): ?>
            <p class="login-error login-success">
                Account created. You can now sign in.
            </p>
        <?php elseif (($_GET['created'] ?? '') === 'pending'): ?>
            <p class="login-error login-success">
                Account created. An administrator needs to activate it before you can sign in.
            </p>
        <?php endif; ?>

        <?php if ($error): ?>
            <p class="login-error"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <?php if ($mode === 'register'): ?>
            <form method="post" action="login.php?mode=register">
                <input type="hidden" name="action" value="register">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['guest_csrf']) ?>">

                <label for="full_name">Full name</label>
                <input type="text" id="full_name" name="full_name" autocomplete="name"
                       maxlength="100" value="<?= htmlspecialchars($formName) ?>" required>

                <label for="email">Email address</label>
                <input type="email" id="email" name="email" autocomplete="username"
                       maxlength="190" value="<?= htmlspecialchars($formEmail) ?>" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" autocomplete="new-password"
                       minlength="8" required>

                <label for="password_confirm">Confirm password</label>
                <input type="password" id="password_confirm" name="password_confirm"
                       autocomplete="new-password" minlength="8" required>

                <button class="btn btn-primary" type="submit">Create account</button>
            </form>
            <p class="login-switch">Already have an account? <a href="login.php">Sign in</a></p>
        <?php else: ?>
            <form method="post">
                <input type="hidden" name="action" value="login">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['guest_csrf']) ?>">

                <label for="email">Email address</label>
                <input type="email" id="email" name="email" autocomplete="username" required>

                <label for="password">Password</label>
                <input type="password" id="password" name="password" autocomplete="current-password" required>

                <button class="btn btn-primary" type="submit">Sign in securely</button>
            </form>
            <p class="login-switch">New here? <a href="login.php?mode=register">Create an account</a></p>
        <?php endif; ?>
    </main>
</body>
</html>
