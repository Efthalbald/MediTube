# MediTube — Deployable Web Application Foundation

MediTube is a PHP 8.1+ / MySQL web application for caregiver-managed medication schedules, dose event records, device telemetry, and an ESP32 integration API. It includes administrator sign-in, password hashing, session protection, CSRF protection for schedule changes, server-side validation, and audit logging.

## Important deployment boundary
This is a deployable software foundation, not a clinically validated medical device. The physical compartment unlock/motor command is deliberately not exposed. The camera page is not an ESP32 video ingestion/recording pipeline. Dose events are not proof that a patient swallowed medication. Before real patient use, obtain engineering and clinical validation, implement physical safety interlocks and verified sensors, and complete privacy/security review.

## Quick start
1. Use PHP 8.1+ with PDO MySQL and MySQL 8 / MariaDB.
2. Create a database and import `database/meditube_db.sql`.
3. Configure database environment variables (see `docs/DEPLOYMENT.md`).
4. Visit `/install.php` once to create the first administrator.
5. Delete `install.php` from the deployed server immediately.
6. Sign in at `/login.php`.

See `docs/DEPLOYMENT.md` and `docs/API.md` before exposing it to the internet.
