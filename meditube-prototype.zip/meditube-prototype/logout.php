<?php

declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

// Record the logout before the session is destroyed.
if (!empty($_SESSION['user_id'])) {
    audit_log($pdo, (int) $_SESSION['user_id'], 'logout', 'session');
}

// Clear session data and expire the session cookie.
$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $cookie = session_get_cookie_params();

    setcookie(
        session_name(),
        '',
        time() - 42000,
        $cookie['path'],
        $cookie['domain'] ?? '',
        (bool) $cookie['secure'],
        (bool) $cookie['httponly']
    );
}

session_destroy();

header('Location: login.php');
exit;
