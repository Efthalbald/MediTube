<?php

declare(strict_types=1);

/**
 * Main dashboard (single page app shell).
 * Visitors who are not signed in are redirected to login.php.
 */

require_once __DIR__ . '/config/bootstrap.php';

require_login();

$csrf     = csrf_token();
$userName = $_SESSION['user_name'] ?? 'Caregiver';
$initials = mb_strtoupper(implode('', array_map(
    static fn (string $word): string => mb_substr($word, 0, 1),
    array_slice(preg_split('/\s+/', trim($userName)) ?: [], 0, 2)
)));
if ($initials === '') {
    $initials = 'U';
}
?>
<!doctype html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <title>MediTube — Medication Care</title>
        <meta name="csrf-token" content="<?= htmlspecialchars($csrf, ENT_QUOTES) ?>" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
        <link
            href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Manrope:wght@400;500;600;700;800&display=swap"
            rel="stylesheet"
        />
        <link
            href="https://fonts.googleapis.com/css2?family=Fredoka:wght@500;600;700&family=Nunito:wght@400;600;700;800&display=swap"
            rel="stylesheet"
        />
        <link rel="stylesheet" href="assets/style.css" />
        <link rel="stylesheet" href="assets/theme.css" />
        <style>
            /* Medication schedule: grows with every added schedule, then scrolls. */
            .schedule-scroll {
                max-height: 420px;
                overflow-y: auto;
                overscroll-behavior: contain;
            }
            .schedule-scroll thead th {
                position: sticky;
                top: 0;
                z-index: 1;
                background: #fff;
            }
            /* Compartment cards: schedules linked to the Medication schedule page. */
            .comp-schedule-list {
                max-height: 170px;
                overflow-y: auto;
                margin: 10px 0 14px;
                border-top: 1px solid #e5e7eb;
            }
            .comp-schedule-row {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 12px;
                padding: 9px 0;
                border-bottom: 1px solid #e5e7eb;
            }
            .comp-schedule-row small {
                display: block;
                color: #6b7280;
            }
            .comp-schedule-time {
                text-align: right;
                white-space: nowrap;
            }
            .comp-schedule-empty {
                padding: 14px 0;
                color: #6b7280;
                font-size: 0.9rem;
                text-align: center;
            }
        </style>
    </head>
    <body>
        <div class="app-shell">
            <aside class="sidebar" id="sidebar">
                <a class="brand" href="#dashboard">
                    <span class="brand-mark"><i></i></span>
                    <span>
                        Medi<span>Tube</span>
                        <small>SMART MEDICATION CARE</small>
                    </span>
                </a>
                <div class="nav-label">MENU</div>
                <nav>
                    <a class="nav-link active" href="#dashboard" data-page="dashboard">
                        <span class="nav-icon">🏡</span>
                        Overview
                    </a>
                    <a class="nav-link" href="#schedule" data-page="schedule">
                        <span class="nav-icon">💊</span>
                        Medication schedule
                    </a>
                    <a class="nav-link" href="#compartments" data-page="compartments">
                        <span class="nav-icon">🧪</span>
                        Compartments
                    </a>
                    <a class="nav-link" href="#history" data-page="history">
                        <span class="nav-icon">📒</span>
                        Dose history
                    </a>
                    <a class="nav-link" href="#videos" data-page="videos">
                        <span class="nav-icon">🎥</span>
                        Video monitoring
                        <span class="nav-count" id="videoCount" hidden>0</span>
                    </a>
                </nav>
                <div class="nav-label second-label">SYSTEM</div>
                <nav>
                    <a class="nav-link" href="#device" data-page="device">
                        <span class="nav-icon">📡</span>
                        Device & connectivity
                    </a>
                    <a class="nav-link" href="#caregivers" data-page="caregivers">
                        <span class="nav-icon">🧸</span>
                        Caregivers
                    </a>
                    <a class="nav-link" href="#settings" data-page="settings">
                        <span class="nav-icon">🎀</span>
                        Settings
                    </a>
                </nav>
                <div class="sidebar-bottom">
                    <div class="profile">
                        <div class="avatar"><?= htmlspecialchars($initials, ENT_QUOTES) ?></div>
                        <div>
                            <b><?= htmlspecialchars($userName, ENT_QUOTES) ?></b>
                            <small>Administrator</small>
                        </div>
                    </div>
                    <a class="nav-link logout-link" href="logout.php">
                        <span class="nav-icon">↪</span>
                        Log out
                    </a>
                </div>
            </aside>
            <main class="main-area">
                <header class="topbar">
                    <button class="mobile-menu" id="mobileMenu">☰</button>
                    <div class="breadcrumb">
                        <b id="crumb">Overview</b>
                    </div>
                    <div class="top-actions">
                        <button class="icon-btn" id="notificationBtn" title="Notifications">
                            ♧
                            <em></em>
                        </button>
                        <div class="top-avatar"><?= htmlspecialchars($initials, ENT_QUOTES) ?></div>
                    </div>
                </header>
                <div class="page-wrap">
                    <section class="page active-page" id="page-dashboard">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow" id="todayLabel"></div>
                                <h1 id="greetingTitle" data-name="<?= htmlspecialchars($userName, ENT_QUOTES) ?>">Hello, <?= htmlspecialchars($userName, ENT_QUOTES) ?> <span>✦</span></h1>
                                <p>Here's what's happening with your medication care today.</p>
                            </div>
                            <button class="btn btn-primary" data-go="schedule">＋ Manage schedule</button>
                        </div>
                        <div class="hero-card">
                            <div class="hero-copy">
                                <div class="hero-tag">
                                    <i></i>
                                    NEXT MEDICATION
                                </div>
                                <h2 id="heroTitle">Loading…</h2>
                                <p id="heroDetail"></p>
                                <div class="hero-meta">
                                    <span id="heroCountdown"></span>
                                    <span id="heroDosage"></span>
                                </div>
                            </div>
                            <div class="hero-visual">
                                <div class="orbit orbit-one"></div>
                                <div class="orbit orbit-two"></div>
                                <div class="pill-bottle">
                                    <div class="bottle-cap"></div>
                                    <div class="bottle-label">
                                        <b>
                                            MEDI
                                            <br />
                                            TUBE
                                        </b>
                                        <small>DAILY CARE</small>
                                    </div>
                                    <div class="bottle-base"></div>
                                </div>
                                <div class="hero-pill p1"></div>
                                <div class="hero-pill p2"></div>
                            </div>
                            <div class="hero-number" id="heroNumber"></div>
                        </div>
                        <div class="stats-grid">
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Today's doses</span>
                                    <span class="stat-icon blue">💊</span>
                                </div>
                                <div class="stat-value" id="statTotal">—</div>
                                <div class="stat-foot" id="statTotalFoot">Loading…</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Doses completed</span>
                                    <span class="stat-icon green">✅</span>
                                </div>
                                <div class="stat-value" id="statDone">—</div>
                                <div class="stat-foot" id="statDoneFoot">Loading…</div>
                                <div class="progress"><i id="statDoneBar" style="width: 0%"></i></div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Device battery</span>
                                    <span class="stat-icon amber">🔋</span>
                                </div>
                                <div class="stat-value" id="devBatteryValue">—</div>
                                <div class="stat-foot" id="devBatteryFoot">No device data yet</div>
                                <div class="progress battery"><i id="devBatteryBar" style="width: 0%"></i></div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Database status</span>
                                    <span class="stat-icon violet">🗄️</span>
                                </div>
                                <div class="stat-value status-value" id="statDb">Checking…</div>
                                <div class="stat-foot">
                                    Last sync
                                    <b id="lastSync">—</b>
                                </div>
                            </div>
                        </div>
                        <div class="content-grid">
                            <div class="panel schedule-panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Today's medication schedule</h3>
                                        <p>Your planned doses and their current status</p>
                                    </div>
                                    <a href="#schedule" data-go="schedule">View schedule →</a>
                                </div>
                                <div class="dose-list" id="dashboardDoses"></div>
                            </div>
                            <div class="panel device-panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Device overview</h3>
                                        <p>MediTube · MT-ESP32-001</p>
                                    </div>
                                    <span class="connected-pill" id="deviceOverviewPill">No data</span>
                                </div>
                                <div class="device-mini">
                                    <div class="mini-device">
                                        <div class="mini-cap"></div>
                                        <div class="mini-lens">◉</div>
                                        <div class="mini-tube blue-tube">01</div>
                                        <div class="mini-tube green-tube">02</div>
                                        <div class="mini-tube purple-tube">03</div>
                                    </div>
                                    <div class="device-info">
                                        <b>MediTube Unit 01</b>
                                        <span id="devOverviewFirmware">Firmware: not reported</span>
                                        <span id="devOverviewWifi">Wi-Fi: not reported</span>
                                        <span>
                                            Signal strength
                                            <b id="devOverviewSignal">Not reported</b>
                                        </span>
                                    </div>
                                </div>
                                <div class="device-bottom">
                                    <div>
                                        <small>Last device heartbeat</small>
                                        <b id="heartbeat">No heartbeat received</b>
                                    </div>
                                    <a href="#device" data-go="device">Details →</a>
                                </div>
                            </div>
                        </div>
                        <div class="content-grid lower-grid">
                            <div class="panel activity-panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Recent activity</h3>
                                        <p>Latest events from your MediTube system</p>
                                    </div>
                                    <a href="#history" data-go="history">Full history →</a>
                                </div>
                                <div class="activity-list" id="recentActivity"></div>
                            </div>
                            <div class="panel alert-panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Care reminders</h3>
                                        <p>Things that may need your attention</p>
                                    </div>
                                    <span class="tiny-count" id="remindersCount">0</span>
                                </div>
                                <div id="careReminders"></div>
                            </div>
                        </div>
                    </section>
                    <section class="page" id="page-schedule">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">MEDICATION MANAGEMENT</div>
                                <h1>Medication schedule</h1>
                                <p>Manage the daily medication plan assigned to each compartment.</p>
                            </div>
                            <button class="btn btn-primary" id="addDose">＋ Add medication</button>
                        </div>
                        <div class="panel">
                            <div class="panel-heading">
                                <div>
                                    <h3>Daily plan</h3>
                                    <p>All scheduled medications. Scroll to see more.</p>
                                </div>
                                <span class="connected-pill" id="scheduleCount">3 active schedules</span>
                            </div>
                            <div id="scheduleTable" class="table-wrap schedule-scroll"></div>
                        </div>
                    </section>
                    <section class="page" id="page-compartments">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">DISPENSER MANAGEMENT</div>
                                <h1>Medication compartments</h1>
                                <p>View each tube, its assigned dose, and its lock status.</p>
                            </div>
                        </div>
                        <div class="compartment-grid" id="compartmentCards"></div>
                    </section>
                    <section class="page" id="page-history">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">RECORDS & ADHERENCE</div>
                                <h1>Dose history</h1>
                                <p>Review medication events reported by the device and caregiver.</p>
                            </div>
                            <button class="btn btn-secondary" id="exportHistory">↓ Export CSV</button>
                        </div>
                        <div class="stats-grid compact-stats">
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Total recorded</span>
                                    <span class="stat-icon blue">📒</span>
                                </div>
                                <div class="stat-value" id="histTotal">—</div>
                                <div class="stat-foot" id="histTotalFoot">Loading…</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Completed</span>
                                    <span class="stat-icon green">✅</span>
                                </div>
                                <div class="stat-value" id="histDone">—</div>
                                <div class="stat-foot" id="histDoneFoot">Loading…</div>
                            </div>
                            <div class="stat-card">
                                <div class="stat-top">
                                    <span>Pending today</span>
                                    <span class="stat-icon amber">⏳</span>
                                </div>
                                <div class="stat-value" id="histPending">—</div>
                                <div class="stat-foot" id="histPendingFoot">Loading…</div>
                            </div>
                        </div>
                        <div class="panel">
                            <div class="panel-heading">
                                <div>
                                    <h3>Medication events</h3>
                                    <p>Latest activity from the MediTube unit</p>
                                </div>
                                <select id="historyFilter" class="filter-select">
                                    <option value="all">All events</option>
                                    <option value="Completed">Completed</option>
                                    <option value="Other">Other events</option>
                                </select>
                            </div>
                            <div id="historyTable" class="table-wrap"></div>
                        </div>
                    </section>
                    <section class="page" id="page-videos">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">CAREGIVER MONITORING</div>
                                <h1>Video monitoring</h1>
                                <p>Review medication-taking clips and device camera availability.</p>
                            </div>
                            <button class="btn btn-primary" id="recordDemo">◉ Start camera preview</button>
                        </div>
                        <div class="video-layout">
                            <div class="panel camera-panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Live camera preview</h3>
                                        <p>Camera module · Inside medication tube</p>
                                    </div>
                                    <span class="connected-pill">
                                        <i></i>
                                        Camera ready
                                    </span>
                                </div>
                                <div class="camera-view">
                                    <div class="camera-crosshair">＋</div>
                                    <div class="camera-lens-art">◉</div>
                                    <div class="camera-caption">MEDItUBE · CAMERA MODULE</div>
                                </div>
                                <div class="camera-controls">
                                    <span id="cameraStatus">
                                        Preview is simulated until a camera stream is connected.
                                    </span>
                                    <button class="btn btn-secondary" id="stopCamera">Stop preview</button>
                                </div>
                                <video id="localVideo" autoplay playsinline muted hidden></video>
                            </div>
                            <div class="panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Recent recordings</h3>
                                        <p>Medication activity videos</p>
                                    </div>
                                </div>
                                <div class="recording-list" id="recordingList">
                                    <div class="empty-video">Loading recordings…</div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="page" id="page-device">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">HARDWARE CONNECTION</div>
                                <h1>Device & connectivity</h1>
                                <p>Monitor the ESP32 connection and inspect the API integration status.</p>
                            </div>
                            <button class="btn btn-secondary" id="refreshDevice">↻ Refresh status</button>
                        </div>
                        <div class="device-detail-grid">
                            <div class="panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>Device connection</h3>
                                        <p>Registered hardware unit</p>
                                    </div>
                                    <span class="connected-pill">
                                        <i id="devicePillDot"></i>
                                        <span id="devicePillText">Checking…</span>
                                    </span>
                                </div>
                                <div class="device-identity">
                                    <div class="device-icon-large">⌁</div>
                                    <div>
                                        <h2>MediTube Unit 01</h2>
                                        <p>
                                            Device ID:
                                            <b>MT-ESP32-001</b>
                                        </p>
                                        <span class="muted">ESP32 · Wi-Fi · HTTP/JSON</span>
                                    </div>
                                </div>
                                <div class="detail-rows">
                                    <div>
                                        <span>Connection</span>
                                        <b id="devConnection">Checking…</b>
                                    </div>
                                    <div>
                                        <span>Firmware</span>
                                        <b id="devFirmware">Not reported</b>
                                    </div>
                                    <div>
                                        <span>Battery</span>
                                        <b id="devBattery">Not reported</b>
                                    </div>
                                    <div>
                                        <span>Wi-Fi signal</span>
                                        <b id="devWifi">Not reported</b>
                                    </div>
                                    <div>
                                        <span>Last heartbeat</span>
                                        <b id="deviceHeartbeat">No heartbeat received</b>
                                    </div>
                                </div>
                            </div>
                            <div class="panel api-panel">
                                <div class="panel-heading">
                                    <div>
                                        <h3>API integration</h3>
                                        <p>ESP32 communication endpoint</p>
                                    </div>
                                    <span class="api-badge">REST API</span>
                                </div>
                                <label>Base API URL</label>
                                <div class="copy-field">
                                    <code id="apiUrl">Detecting…</code>
                                    <button data-copy="apiUrl">Copy</button>
                                </div>
                                <p class="muted" style="margin: 8px 0">
                                    The ESP32 must reach this address over your Wi-Fi. If it shows
                                    "localhost", replace it with this computer's network IP (for example
                                    http://192.168.1.10/meditube/api).
                                </p>
                                <div class="api-endpoints">
                                    <b>Available endpoints</b>
                                    <code>GET /device.php?action=schedule</code>
                                    <code>POST /device.php?action=heartbeat</code>
                                    <code>POST /device.php?action=event</code>
                                </div>
                                <a href="docs/API.md" class="text-link">Read API documentation →</a>
                            </div>
                        </div>
                        <div class="panel telemetry-panel">
                            <div class="panel-heading">
                                <div>
                                    <h3>Latest device telemetry</h3>
                                    <p id="telemetrySubtitle">Latest reading reported by the ESP32</p>
                                </div>
                                <span class="muted">Refreshes every 15 seconds</span>
                            </div>
                            <div class="telemetry-grid">
                                <div>
                                    <small>Battery voltage</small>
                                    <b id="telVoltage">—</b>
                                    <span id="telVoltageNote">No data yet</span>
                                </div>
                                <div>
                                    <small>Wi-Fi RSSI</small>
                                    <b id="telRssi">—</b>
                                    <span id="telRssiNote">No data yet</span>
                                </div>
                                <div>
                                    <small>Door sensor</small>
                                    <b id="telDoor">—</b>
                                    <span id="telDoorNote">No data yet</span>
                                </div>
                                <div>
                                    <small>Motor status</small>
                                    <b id="telMotor">—</b>
                                    <span id="telMotorNote">No data yet</span>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="page" id="page-caregivers">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">PEOPLE & ACCESS</div>
                                <h1>Caregivers</h1>
                                <p>People who can review medication activity and device alerts.</p>
                            </div>
                            <button class="btn btn-primary" id="inviteCaregiver">＋ Add caregiver</button>
                        </div>
                        <div class="panel caregiver-list">
                            <div class="caregiver-row">
                                <div class="avatar caregiver-avatar"><?= htmlspecialchars($initials, ENT_QUOTES) ?></div>
                                <div>
                                    <b><?= htmlspecialchars($userName, ENT_QUOTES) ?></b>
                                    <small>admin@meditube.local · Primary caregiver</small>
                                </div>
                                <span class="role-pill">Administrator</span>
                                <span class="green-text">Active</span>
                            </div>
                            <div class="caregiver-row">
                                <div class="avatar caregiver-avatar alt-avatar">MR</div>
                                <div>
                                    <b>Maria Reyes</b>
                                    <small>maria@example.com · Family caregiver</small>
                                </div>
                                <span class="role-pill">Viewer</span>
                                <span class="green-text">Active</span>
                            </div>
                        </div>
                    </section>
                    <section class="page" id="page-settings">
                        <div class="page-heading">
                            <div>
                                <div class="eyebrow">PREFERENCES</div>
                                <h1>Settings</h1>
                                <p>Configure your MediTube workspace and notification preferences.</p>
                            </div>
                        </div>
                        <div class="panel settings-panel">
                            <h3>Preferences</h3>
                            <div class="setting-row">
                                <div>
                                    <b>Medication reminders</b>
                                    <p>Show reminder notifications for scheduled doses.</p>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span></span>
                                </label>
                            </div>
                            <div class="setting-row">
                                <div>
                                    <b>Low battery alert</b>
                                    <p>Notify caregivers when battery drops below 20%.</p>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span></span>
                                </label>
                            </div>
                            <div class="setting-row">
                                <div>
                                    <b>Missed-dose alert</b>
                                    <p>Flag doses that remain unconfirmed after their scheduled window.</p>
                                </div>
                                <label class="switch">
                                    <input type="checkbox" checked />
                                    <span></span>
                                </label>
                            </div>
                            <div class="setting-row">
                                <div>
                                    <b>Device identifier</b>
                                    <p>MT-ESP32-001</p>
                                </div>
                                <span class="muted">Read only</span>
                            </div>
                        </div>
                        <div class="panel settings-panel">
                            <h3>Application information</h3>
                            <p class="muted">
                                MediTube provides caregiver-facing schedule management and device event
                                monitoring. Device telemetry depends on a configured ESP32 connection.
                                Recorded device events do not independently verify medication ingestion.
                            </p>
                        </div>
                    </section>
                    <footer class="footer">
                        © 2026 MediTube · Smart Medication Care
                        <span>Prototype build 1.0.0</span>
                    </footer>
                </div>
            </main>
        </div>
        <div class="toast" id="toast"></div>
        <div class="modal-backdrop" id="doseModal">
            <div class="modal">
                <div class="modal-head">
                    <div>
                        <h3>Add medication schedule</h3>
                        <p>Assign a dose to a dispenser compartment.</p>
                    </div>
                    <button class="close-modal" data-close>×</button>
                </div>
                <form id="doseForm">
                    <label>
                        Medication name
                        <input name="name" required placeholder="e.g. Vitamin C" />
                    </label>
                    <div class="form-row">
                        <label>
                            Compartment
                            <select name="compartment">
                                <option value="1">Compartment 1</option>
                                <option value="2">Compartment 2</option>
                                <option value="3">Compartment 3</option>
                            </select>
                        </label>
                        <label>
                            Scheduled time
                            <input type="time" name="time" required value="08:00" />
                        </label>
                    </div>
                    <div class="form-row">
                        <label>
                            Dosage
                            <input name="dosage" placeholder="1 tablet" required />
                        </label>
                        <label>
                            Color
                            <select name="color">
                                <option value="blue">Blue</option>
                                <option value="green">Green</option>
                                <option value="purple">Purple</option>
                            </select>
                        </label>
                    </div>
                    <button class="btn btn-primary full-btn" type="submit">Save schedule</button>
                </form>
            </div>
        </div>
        <script src="assets/app.js"></script>
    </body>
</html>