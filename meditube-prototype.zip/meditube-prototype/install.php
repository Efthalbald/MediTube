<?php

declare(strict_types=1);

/**
 * One-time installer: creates the first administrator account.
 * Delete this file from the server right after setup.
 */

require_once __DIR__ . '/config/bootstrap.php';

// Refuse to run once any user exists.
$userCount = (int) $pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();

if ($userCount > 0) {
    http_response_code(403);
    exit('Installation is already complete. Delete install.php from your server.');
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tokenIsValid = hash_equals($_SESSION['install_csrf'] ?? '', $_POST['csrf'] ?? '');

    if (!$tokenIsValid) {
        $error = 'Invalid form token. Refresh this page.';
    } else {
        $name     = trim($_POST['name'] ?? '');
        $email    = strtolower(trim($_POST['email'] ?? ''));
        $password = $_POST['password'] ?? '';

        $inputIsValid = $name !== ''
            && filter_var($email, FILTER_VALIDATE_EMAIL)
            && strlen($password) >= 12;

        if (!$inputIsValid) {
            $error = 'Enter your name, a valid email, and a password of at least 12 characters.';
        } else {
            $statement = $pdo->prepare(
                "INSERT INTO users (full_name, email, password_hash, role)
                 VALUES (?, ?, ?, 'admin')"
            );
            $statement->execute([$name, $email, password_hash($password, PASSWORD_DEFAULT)]);

            header('Location: login.php?installed=1');
            exit;
        }
    }
}

$_SESSION['install_csrf'] = bin2hex(random_bytes(32));
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Set up MediTube</title>
    <link rel="stylesheet" href="assets/install.css">
</head>
<body>
    <div class="card">
        <h1>Set up MediTube</h1>
        <p>Create the first administrator account.</p>

        <?php if ($error): ?>
            <p class="err"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>

        <form method="post">
            <input type="hidden" name="csrf" value="<?= htmlspecialchars($_SESSION['install_csrf']) ?>">

            <label for="name">Full name</label>
            <input id="name" name="name" required>

            <label for="email">Email address</label>
            <input id="email" name="email" type="email" required>

            <label for="password">Password</label>
            <input id="password" name="password" type="password" minlength="12" required>
            <small>Use at least 12 characters. Delete install.php after setup.</small>

            <p><button type="submit">Create administrator</button></p>
        </form>
    </div>
</body>
</html>
