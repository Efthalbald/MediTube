# MediTube Deployment Guide

## Supported stack
- PHP 8.1 or newer (8.2+ recommended)
- MySQL 8.0+ or a compatible MariaDB release
- PHP extensions: pdo_mysql, json, openssl
- Apache with mod_rewrite/mod_headers or an equivalent PHP-capable host
- HTTPS certificate for any public deployment

## 1. Database
Create a database (for example `meditube_db`) and import `database/meditube_db.sql` using phpMyAdmin or your hosting control panel. Use a dedicated database user with access only to this database; do not use the MySQL root account in production.

## 2. Environment configuration
Set these environment variables in your hosting panel / PHP-FPM pool / server environment:

- `MEDITUBE_DB_HOST` — database host
- `MEDITUBE_DB_NAME` — database name
- `MEDITUBE_DB_USER` — dedicated database user
- `MEDITUBE_DB_PASS` — strong database password
- `MEDITUBE_DEVICE_KEY` — long random device API secret (32+ random bytes)
- `MEDITUBE_DEVICE_ORIGIN` — optional exact browser origin if cross-origin device requests are needed

Do not commit secrets to source control. The device API rejects all requests until `MEDITUBE_DEVICE_KEY` is configured.

## 3. Upload and first administrator
Upload the contents of this folder to your hosting document root (or a subfolder). Import the database, then visit `/install.php` over HTTPS to create the first admin account. Use a unique password with at least 12 characters. Immediately delete `install.php` after successful setup. Sign in at `/login.php`.

## 4. Apache / hosting security
- Force HTTPS at the hosting control panel.
- Keep PHP and database software patched.
- Set the document root to this application folder where possible.
- Ensure `uploads/` is not executable; store user-uploaded media outside the web root or on private object storage.
- Configure backups and test restoration.
- Restrict admin access and use unique accounts.
- Do not expose phpMyAdmin or XAMPP publicly.
- Configure server time zone to Asia/Manila if that is the deployment locale.

## 5. ESP32 connection
The ESP32 must use the public HTTPS base URL of the hosted API (or the computer's LAN IP for local testing). Configure the same `MEDITUBE_DEVICE_KEY` in the ESP32 firmware. Do not use `localhost` from the ESP32. For public deployment, use TLS certificate validation in firmware; never disable certificate checks.

## 6. Pre-launch checklist
- [ ] HTTPS enforced and certificate valid
- [ ] Default/demo credentials removed; administrator password changed
- [ ] `install.php` deleted
- [ ] Database user is least-privilege
- [ ] Device key generated and stored securely
- [ ] ESP32 TLS verification enabled for internet use
- [ ] Backups and restore test completed
- [ ] Audit log and error log retention configured
- [ ] Privacy notice, consent, retention, and access policies approved
- [ ] Security review / vulnerability testing completed
- [ ] Hardware safety and clinical validation completed before dispensing medication

This package is not a medical-device certification or a guarantee of regulatory compliance.
