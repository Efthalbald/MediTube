# MediTube REST API

Base path: `/api/device.php`. All device endpoints require `X-Device-Key` matching the server environment variable `MEDITUBE_DEVICE_KEY`. The API fails closed if no key is configured. Use HTTPS on public networks.

## Get active medication schedule
`GET /api/device.php?action=schedule`

## Device heartbeat
`POST /api/device.php?action=heartbeat` with JSON:
```json
{"device_id":"MT-ESP32-001","battery_voltage":4.08,"battery_percent":86,"wifi_rssi":-54,"door_state":"closed","motor_state":"idle"}
```

## Record a device event
`POST /api/device.php?action=event` with JSON:
```json
{"device_id":"MT-ESP32-001","compartment":1,"event_type":"dispense_mechanism_cycle_complete","medication_name":"Morning medication","details":"Sensor feedback received"}
```

## Admin schedule API
`GET /api/admin_schedule.php` requires a signed-in administrator/caregiver session. `POST` also requires `X-CSRF-Token` matching the `csrf-token` meta tag rendered in the signed-in dashboard. Allowed compartments are 1–3. Schedule values are validated server-side.

## Safety
No remote motor unlock endpoint is included. A device event must not be interpreted as proof of ingestion. Add independent hardware safety interlocks, physical feedback, fail-safe behavior, and an appropriately reviewed authorization model before enabling actuation.
