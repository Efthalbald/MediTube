# Local development with XAMPP

1. Copy the project folder into `C:\xampp\htdocs\meditube`.
2. Start Apache and MySQL.
3. Import `database/meditube_db.sql` using phpMyAdmin.
4. Configure `config/database.php` defaults for local XAMPP, or set environment variables.
5. Set `MEDITUBE_DEVICE_KEY` in the Apache/PHP environment before testing ESP32 API.
6. Visit `http://localhost/meditube/install.php` once and create an admin account.
7. Delete `install.php`, then sign in at `http://localhost/meditube/login.php`.

For public hosting, use `docs/DEPLOYMENT.md`. Do not expose XAMPP directly to the internet.
