-- MediTube database schema and sample data.
-- Import this file once (phpMyAdmin or `mysql < meditube_db.sql`).

CREATE DATABASE IF NOT EXISTS meditube_db
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE meditube_db;

-- ---------------------------------------------------------------------------
-- Medication schedule: one row per dispenser compartment (1-3)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS medication_schedule (
    id              INT AUTO_INCREMENT PRIMARY KEY,
    compartment     TINYINT      NOT NULL UNIQUE,
    medication_name VARCHAR(120) NOT NULL,
    dosage          VARCHAR(80)  NOT NULL,
    scheduled_time  TIME         NOT NULL,
    active          TINYINT(1)   NOT NULL DEFAULT 1,
    created_at      TIMESTAMP             DEFAULT CURRENT_TIMESTAMP
);

-- ---------------------------------------------------------------------------
-- Device heartbeat / telemetry sent by the ESP32
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS device_telemetry (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    device_id       VARCHAR(64)  NOT NULL,
    battery_voltage DECIMAL(5,2) NULL,
    battery_percent TINYINT      NULL,
    wifi_rssi       SMALLINT     NULL,
    door_state      VARCHAR(32)  NULL,
    motor_state     VARCHAR(32)  NULL,
    payload_json    JSON         NULL,
    received_at     TIMESTAMP             DEFAULT CURRENT_TIMESTAMP,
    INDEX (device_id, received_at)
);

-- ---------------------------------------------------------------------------
-- Dose / compartment events reported by the device
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS dose_events (
    id              BIGINT AUTO_INCREMENT PRIMARY KEY,
    device_id       VARCHAR(64)  NOT NULL,
    compartment     TINYINT      NOT NULL,
    event_type      VARCHAR(40)  NOT NULL,
    medication_name VARCHAR(120) NULL,
    details         TEXT         NULL,
    created_at      TIMESTAMP             DEFAULT CURRENT_TIMESTAMP,
    INDEX (device_id, created_at)
);

-- ---------------------------------------------------------------------------
-- User accounts (created through install.php)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS users (
    id            BIGINT AUTO_INCREMENT PRIMARY KEY,
    full_name     VARCHAR(120) NOT NULL,
    email         VARCHAR(190) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role          ENUM('admin', 'caregiver') NOT NULL DEFAULT 'admin',
    active        TINYINT(1)   NOT NULL DEFAULT 1,
    created_at    TIMESTAMP             DEFAULT CURRENT_TIMESTAMP,
    last_login_at DATETIME     NULL
);

-- ---------------------------------------------------------------------------
-- Audit trail of sign-ins and schedule changes
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
    id           BIGINT AUTO_INCREMENT PRIMARY KEY,
    user_id      BIGINT       NULL,
    action       VARCHAR(80)  NOT NULL,
    entity_type  VARCHAR(80)  NULL,
    entity_id    VARCHAR(80)  NULL,
    details_json JSON         NULL,
    ip_address   VARCHAR(45)  NULL,
    created_at   TIMESTAMP             DEFAULT CURRENT_TIMESTAMP,
    INDEX (created_at),
    INDEX (user_id)
);

-- ---------------------------------------------------------------------------
-- Sample schedule (safe to re-run)
-- ---------------------------------------------------------------------------
INSERT INTO medication_schedule (compartment, medication_name, dosage, scheduled_time) VALUES
    (1, 'Morning medication', '1 tablet',  '08:00:00'),
    (2, 'Midday medication',  '1 tablet',  '12:00:00'),
    (3, 'Evening medication', '1 capsule', '18:00:00')
ON DUPLICATE KEY UPDATE medication_name = VALUES(medication_name);
