/*
  MediTube ESP32 starter firmware
  - Connects to Wi-Fi
  - Retrieves medication schedule using HTTP GET
  - Sends heartbeat telemetry using HTTP POST
  - Sends dose/compartment events using HTTP POST

  IMPORTANT: This is an integration starter, not production dispenser firmware.
  Motor/lock actuation is deliberately NOT implemented. Add hardware-specific
  driver logic, limit switches, jam detection, fail-safe states and physical
  interlocks only after bench testing. Never rely on a web command alone to
  release medication.
*/

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoJson.h>

// ---------------------------------------------------------------------------
// Settings (edit these before uploading)
// ---------------------------------------------------------------------------
const char* WIFI_SSID     = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* API_BASE      = "https://YOUR-DOMAIN.example/api";      // Use your PC's LAN IP, not localhost
const char* DEVICE_KEY    = "PASTE_YOUR_SERVER_DEVICE_KEY_HERE";    // Match MEDITUBE_DEVICE_KEY on server
const char* DEVICE_ID     = "MT-ESP32-001";

const unsigned long HEARTBEAT_INTERVAL = 60000;   // 1 minute
const unsigned long SCHEDULE_INTERVAL  = 300000;  // 5 minutes

// ---------------------------------------------------------------------------
// State
// ---------------------------------------------------------------------------
unsigned long lastHeartbeat    = 0;
unsigned long lastScheduleSync = 0;

// ---------------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------------
void setup() {
  Serial.begin(115200);

  connectWifi();
  fetchSchedule();
  sendHeartbeat();
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    WiFi.reconnect();
    delay(1000);
    return;
  }

  if (millis() - lastHeartbeat >= HEARTBEAT_INTERVAL) {
    sendHeartbeat();
  }

  if (millis() - lastScheduleSync >= SCHEDULE_INTERVAL) {
    fetchSchedule();
  }

  // TODO: Read RTC/time source, buttons, compartment sensors and motor feedback.
  // Compare current time with schedule locally. Do not actuate a lock until a
  // safety-validated state machine and caregiver override are implemented.

  delay(100);
}

// ---------------------------------------------------------------------------
// Wi-Fi
// ---------------------------------------------------------------------------
void connectWifi() {
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  Serial.print("Connecting to Wi-Fi");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print('.');
  }

  Serial.println("\nConnected. ESP32 IP: " + WiFi.localIP().toString());
}

// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------

// Adds the device key and JSON content type to a request.
void addAuth(HTTPClient &http) {
  http.addHeader("X-Device-Key", DEVICE_KEY);
  http.addHeader("Content-Type", "application/json");
}

// ---------------------------------------------------------------------------
// API calls
// ---------------------------------------------------------------------------

// GET the active medication schedule and print it to the serial monitor.
void fetchSchedule() {
  HTTPClient http;
  String url = String(API_BASE) + "/device.php?action=schedule";

  http.begin(url);
  http.addHeader("X-Device-Key", DEVICE_KEY);
  int code = http.GET();

  if (code > 0) {
    String response = http.getString();
    Serial.printf("Schedule HTTP %d\n%s\n", code, response.c_str());

    DynamicJsonDocument doc(4096);
    bool parsed = deserializeJson(doc, response) == DeserializationError::Ok;

    if (parsed && doc["ok"] == true) {
      JsonArray schedule = doc["schedule"].as<JsonArray>();

      for (JsonObject dose : schedule) {
        Serial.printf(
          "Compartment %d: %s at %s (%s)\n",
          dose["compartment"].as<int>(),
          dose["medication_name"].as<const char*>(),
          dose["scheduled_time"].as<const char*>(),
          dose["dosage"].as<const char*>()
        );
      }

      // TODO: Copy schedule into persistent local storage (Preferences/NVS).
    }
  } else {
    Serial.printf("Schedule request failed: %s\n", http.errorToString(code).c_str());
  }

  http.end();
  lastScheduleSync = millis();
}

// POST battery / Wi-Fi / sensor status.
void sendHeartbeat() {
  HTTPClient http;
  http.begin(String(API_BASE) + "/device.php?action=heartbeat");
  addAuth(http);

  DynamicJsonDocument doc(512);
  doc["device_id"]       = DEVICE_ID;
  doc["battery_voltage"] = 4.08;     // TODO: Replace with calibrated ADC voltage divider reading.
  doc["battery_percent"] = 86;       // TODO: Calculate from measured battery voltage.
  doc["wifi_rssi"]       = WiFi.RSSI();
  doc["door_state"]      = "closed"; // TODO: Replace with actual sensor state.
  doc["motor_state"]     = "idle";   // TODO: Replace with actual motor controller state.

  String payload;
  serializeJson(doc, payload);

  int code = http.POST(payload);
  Serial.printf("Heartbeat HTTP %d: %s\n", code, http.getString().c_str());

  http.end();
  lastHeartbeat = millis();
}

// POST a dose / compartment event (call this from your sensor code).
void sendDoseEvent(int compartment, const char* eventType, const char* medicationName, const char* details) {
  HTTPClient http;
  http.begin(String(API_BASE) + "/device.php?action=event");
  addAuth(http);

  DynamicJsonDocument doc(512);
  doc["device_id"]       = DEVICE_ID;
  doc["compartment"]     = compartment;
  doc["event_type"]      = eventType;
  doc["medication_name"] = medicationName;
  doc["details"]         = details;

  String payload;
  serializeJson(doc, payload);

  int code = http.POST(payload);
  Serial.printf("Event HTTP %d: %s\n", code, http.getString().c_str());

  http.end();
}
