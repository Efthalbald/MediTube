<?php

declare(strict_types=1);

/**
 * Device API used by the ESP32.
 *
 *   GET  ?action=schedule   -> active medication schedule
 *   POST ?action=heartbeat  -> store battery / Wi-Fi / sensor telemetry
 *   POST ?action=event      -> store a dose / compartment event
 *
 * Every request must send the X-Device-Key header matching the
 * MEDITUBE_DEVICE_KEY environment variable. If no key is configured the API
 * rejects everything (fails closed).
 */

const DEFAULT_DEVICE_ID = 'MT-ESP32-001';
const MAX_COMPARTMENT   = 3;

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

// ---------------------------------------------------------------------------
// CORS (only for the one origin allowed in MEDITUBE_DEVICE_ORIGIN)
// ---------------------------------------------------------------------------

$allowedOrigin = getenv('MEDITUBE_DEVICE_ORIGIN') ?: '';
$origin        = $_SERVER['HTTP_ORIGIN'] ?? '';

if ($allowedOrigin !== '' && $origin !== '' && hash_equals($allowedOrigin, $origin)) {
    header('Access-Control-Allow-Origin: ' . $allowedOrigin);
}

header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Device-Key');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

// ---------------------------------------------------------------------------
// Device authentication
// ---------------------------------------------------------------------------

$deviceKey   = getenv('MEDITUBE_DEVICE_KEY') ?: '';
$providedKey = $_SERVER['HTTP_X_DEVICE_KEY'] ?? '';

if ($deviceKey === '' || $providedKey === '' || !hash_equals($deviceKey, $providedKey)) {
    http_response_code(401);
    echo json_encode(['ok' => false, 'error' => 'Device authentication failed']);
    exit;
}

require_once __DIR__ . '/../config/database.php';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function input_data(): array
{
    $decoded = json_decode(file_get_contents('php://input'), true);

    return is_array($decoded) ? $decoded : [];
}

function fail(int $status, string $message): never
{
    http_response_code($status);
    echo json_encode(['ok' => false, 'error' => $message]);
    exit;
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------

function handle_schedule(PDO $pdo): void
{
    $rows = $pdo->query(
        "SELECT id, compartment, medication_name, dosage,
                TIME_FORMAT(scheduled_time, '%H:%i:%s') AS scheduled_time,
                active
         FROM medication_schedule
         WHERE active = 1
         ORDER BY scheduled_time"
    )->fetchAll();

    echo json_encode([
        'ok'          => true,
        'device_id'   => DEFAULT_DEVICE_ID,
        'server_time' => date(DATE_ATOM),
        'schedule'    => $rows,
    ]);
}

function handle_heartbeat(PDO $pdo): void
{
    $body = input_data();

    $percent = isset($body['battery_percent'])
        ? filter_var($body['battery_percent'], FILTER_VALIDATE_INT)
        : null;

    if ($percent !== null && ($percent < 0 || $percent > 100)) {
        fail(422, 'Invalid battery percentage');
    }

    $statement = $pdo->prepare(
        'INSERT INTO device_telemetry
             (device_id, battery_voltage, battery_percent, wifi_rssi, door_state, motor_state, payload_json)
         VALUES (?, ?, ?, ?, ?, ?, ?)'
    );

    $statement->execute([
        substr((string) ($body['device_id'] ?? DEFAULT_DEVICE_ID), 0, 64),
        $body['battery_voltage'] ?? null,
        $percent,
        $body['wifi_rssi'] ?? null,
        $body['door_state'] ?? null,
        $body['motor_state'] ?? null,
        json_encode($body),
    ]);

    echo json_encode(['ok' => true, 'server_time' => date(DATE_ATOM)]);
}

function handle_event(PDO $pdo): void
{
    $body = input_data();

    $compartment = (int) ($body['compartment'] ?? 0);
    $eventType   = substr((string) ($body['event_type'] ?? ''), 0, 40);

    if ($compartment < 1 || $compartment > MAX_COMPARTMENT || $eventType === '') {
        fail(422, 'Invalid event');
    }

    $statement = $pdo->prepare(
        'INSERT INTO dose_events (device_id, compartment, event_type, medication_name, details)
         VALUES (?, ?, ?, ?, ?)'
    );

    $statement->execute([
        substr((string) ($body['device_id'] ?? DEFAULT_DEVICE_ID), 0, 64),
        $compartment,
        $eventType,
        substr((string) ($body['medication_name'] ?? ''), 0, 120),
        substr((string) ($body['details'] ?? ''), 0, 1000),
    ]);

    echo json_encode(['ok' => true, 'event_id' => $pdo->lastInsertId()]);
}

// ---------------------------------------------------------------------------
// Router
// ---------------------------------------------------------------------------

try {
    $action = $_GET['action'] ?? '';
    $method = $_SERVER['REQUEST_METHOD'];

    if ($action === 'schedule' && $method === 'GET') {
        handle_schedule($pdo);
    } elseif ($action === 'heartbeat' && $method === 'POST') {
        handle_heartbeat($pdo);
    } elseif ($action === 'event' && $method === 'POST') {
        handle_event($pdo);
    } else {
        fail(400, 'Unknown action or method');
    }
} catch (Throwable $e) {
    error_log('MediTube device API: ' . $e->getMessage());
    fail(500, 'Server error');
}
