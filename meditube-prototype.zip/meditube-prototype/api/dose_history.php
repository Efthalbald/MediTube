<?php

declare(strict_types=1);

/**
 * Dose history API (session protected, read only).
 *
 *   GET -> latest events from dose_events plus real summary counts
 */

require_once __DIR__ . '/../config/bootstrap.php';

require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    $rows = $pdo->query(
        'SELECT id, device_id, compartment, event_type, medication_name, details, created_at
         FROM dose_events
         ORDER BY created_at DESC, id DESC
         LIMIT 200'
    )->fetchAll();

    $events = array_map(static function (array $row): array {
        $timestamp = strtotime((string) $row['created_at']) ?: time();
        $type      = (string) $row['event_type'];

        return [
            'id'              => (int) $row['id'],
            'compartment'     => (int) $row['compartment'],
            'event_type'      => $type,
            'completed'       => $type === 'dose_completed',
            'medication_name' => $row['medication_name'],
            'details'         => $row['details'],
            'source'          => $row['device_id'] === 'dashboard' ? 'Caregiver (dashboard)' : (string) $row['device_id'],
            'date'            => date('M j, Y', $timestamp),
            'time'            => date('g:i A', $timestamp),
        ];
    }, $rows);

    $count = static fn (string $sql): int => (int) $GLOBALS['pdo']->query($sql)->fetchColumn();

    $stats = [
        'total'           => $count('SELECT COUNT(*) FROM dose_events'),
        'completed'       => $count("SELECT COUNT(*) FROM dose_events WHERE event_type = 'dose_completed'"),
        'completed_today' => $count("SELECT COUNT(*) FROM dose_events
                                     WHERE event_type = 'dose_completed' AND DATE(created_at) = CURDATE()"),
        'pending_today'   => $count("SELECT COUNT(*) FROM medication_schedule s
                                     WHERE s.active = 1
                                       AND NOT EXISTS (
                                           SELECT 1 FROM dose_events e
                                           WHERE e.schedule_id = s.id
                                             AND e.event_type = 'dose_completed'
                                             AND e.device_id = 'dashboard'
                                             AND DATE(e.created_at) = CURDATE()
                                       )"),
    ];

    echo json_encode(['ok' => true, 'events' => $events, 'stats' => $stats]);
} catch (Throwable $e) {
    error_log('MediTube dose history API: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Unable to load dose history']);
}
