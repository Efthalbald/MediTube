<?php

declare(strict_types=1);

/**
 * Device status API (session protected, read only).
 *
 *   GET -> the newest reading the ESP32 sent to device_telemetry, plus how
 *          long ago it arrived. Nothing here is simulated: with no row in the
 *          table the response says "no data".
 */

require_once __DIR__ . '/../config/bootstrap.php';

require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

/** The device counts as online if it reported within this many seconds. */
const ONLINE_WITHIN_SECONDS = 120;

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    http_response_code(405);
    echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
    exit;
}

try {
    // TIMESTAMPDIFF uses the database clock for both sides, so time zones can't skew it.
    $row = $pdo->query(
        'SELECT device_id, battery_voltage, battery_percent, wifi_rssi, door_state, motor_state,
                payload_json, received_at,
                TIMESTAMPDIFF(SECOND, received_at, NOW()) AS seconds_ago
         FROM device_telemetry
         ORDER BY received_at DESC, id DESC
         LIMIT 1'
    )->fetch();

    if (!$row) {
        echo json_encode(['ok' => true, 'has_data' => false, 'online' => false]);
        exit;
    }

    $payload  = json_decode((string) ($row['payload_json'] ?? ''), true);
    $firmware = is_array($payload) ? ($payload['firmware'] ?? $payload['fw'] ?? null) : null;
    $secondsAgo = max(0, (int) $row['seconds_ago']);

    echo json_encode([
        'ok'              => true,
        'has_data'        => true,
        'online'          => $secondsAgo <= ONLINE_WITHIN_SECONDS,
        'device_id'       => $row['device_id'],
        'battery_voltage' => $row['battery_voltage'] === null ? null : (float) $row['battery_voltage'],
        'battery_percent' => $row['battery_percent'] === null ? null : (int) $row['battery_percent'],
        'wifi_rssi'       => $row['wifi_rssi'] === null ? null : (int) $row['wifi_rssi'],
        'door_state'      => $row['door_state'],
        'motor_state'     => $row['motor_state'],
        'firmware'        => is_string($firmware) ? $firmware : null,
        'seconds_ago'     => $secondsAgo,
        'received_at'     => date('M j, Y g:i A', strtotime((string) $row['received_at']) ?: time()),
    ]);
} catch (Throwable $e) {
    error_log('MediTube device status API: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Unable to load device status']);
}
