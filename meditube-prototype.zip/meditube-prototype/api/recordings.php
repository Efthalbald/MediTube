<?php

declare(strict_types=1);

/**
 * Recordings API (session protected).
 *
 *   GET                 -> list saved recordings
 *   GET  ?file=NAME     -> stream one recording
 *   POST                -> save a recording (raw video body, CSRF protected)
 *   POST ?delete=NAME   -> delete one recording (CSRF protected)
 */

require_once __DIR__ . '/../config/bootstrap.php';

require_login();

header('Cache-Control: no-store');

const MAX_RECORDING_BYTES = 200 * 1024 * 1024; // 200 MB
const FILE_PATTERN = '/^rec_\d{8}_\d{6}\.(webm|mp4)$/';

$dir = __DIR__ . '/../recordings';

if (!is_dir($dir)) {
    mkdir($dir, 0775, true);
}

// Block direct web access: files are only served through this script.
if (!file_exists($dir . '/.htaccess')) {
    file_put_contents($dir . '/.htaccess', "Require all denied\n");
}

try {
    $method = $_SERVER['REQUEST_METHOD'];

    // -----------------------------------------------------------------------
    // GET: stream one recording
    // -----------------------------------------------------------------------
    if ($method === 'GET' && isset($_GET['file'])) {
        $file = (string) $_GET['file'];
        $path = $dir . '/' . $file;

        if (preg_match(FILE_PATTERN, $file) !== 1 || !is_file($path)) {
            http_response_code(404);
            exit('Not found');
        }

        header('Content-Type: ' . (str_ends_with($file, '.mp4') ? 'video/mp4' : 'video/webm'));
        header('Content-Length: ' . filesize($path));
        header('X-Content-Type-Options: nosniff');
        readfile($path);
        exit;
    }

    header('Content-Type: application/json; charset=utf-8');

    // -----------------------------------------------------------------------
    // GET: list recordings (newest first)
    // -----------------------------------------------------------------------
    if ($method === 'GET') {
        $files = glob($dir . '/rec_*.{webm,mp4}', GLOB_BRACE) ?: [];
        rsort($files);

        $recordings = array_map(static fn (string $path): array => [
            'file' => basename($path),
            'size' => filesize($path),
            'time' => date('M j, Y g:i A', (int) filemtime($path)),
        ], $files);

        echo json_encode(['ok' => true, 'recordings' => $recordings]);
        exit;
    }

    if ($method !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
        exit;
    }

    verify_csrf();

    // -----------------------------------------------------------------------
    // POST ?delete=NAME: delete one recording
    // -----------------------------------------------------------------------
    if (isset($_GET['delete'])) {
        $file = (string) $_GET['delete'];
        $path = $dir . '/' . $file;

        if (preg_match(FILE_PATTERN, $file) !== 1 || !is_file($path)) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'error' => 'Recording not found']);
            exit;
        }

        if (!unlink($path)) {
            http_response_code(500);
            echo json_encode(['ok' => false, 'error' => 'Unable to delete recording']);
            exit;
        }

        audit_log($pdo, (int) $_SESSION['user_id'], 'recording_deleted', 'recording', $file);

        echo json_encode(['ok' => true, 'message' => 'Recording deleted']);
        exit;
    }

    // -----------------------------------------------------------------------
    // POST: save a recording
    // -----------------------------------------------------------------------
    $type = strtolower(trim(explode(';', $_SERVER['CONTENT_TYPE'] ?? '')[0]));
    $ext  = ['video/webm' => 'webm', 'video/mp4' => 'mp4'][$type] ?? null;

    if ($ext === null) {
        http_response_code(415);
        echo json_encode(['ok' => false, 'error' => 'Unsupported video format']);
        exit;
    }

    $name = 'rec_' . date('Ymd_His') . '.' . $ext;
    $path = $dir . '/' . $name;

    $in  = fopen('php://input', 'rb');
    $out = fopen($path, 'xb');

    if ($in === false || $out === false) {
        http_response_code(500);
        echo json_encode(['ok' => false, 'error' => 'Unable to write recording']);
        exit;
    }

    $bytes = (int) stream_copy_to_stream($in, $out, MAX_RECORDING_BYTES + 1);
    fclose($in);
    fclose($out);

    if ($bytes <= 0) {
        @unlink($path);
        http_response_code(413);
        echo json_encode(['ok' => false, 'error' => 'Recording is empty or larger than the server upload limit']);
        exit;
    }

    if ($bytes > MAX_RECORDING_BYTES) {
        @unlink($path);
        http_response_code(413);
        echo json_encode(['ok' => false, 'error' => 'Recording is too large']);
        exit;
    }

    audit_log($pdo, (int) $_SESSION['user_id'], 'recording_saved', 'recording', $name, ['bytes' => $bytes]);

    echo json_encode(['ok' => true, 'file' => $name, 'size' => $bytes]);
} catch (Throwable $e) {
    error_log('MediTube recordings API: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Unable to process recording request']);
}
