<?php

declare(strict_types=1);

/**
 * Admin schedule API (session protected).
 *
 *   GET  -> list every schedule row (with today's status)
 *   POST -> add a schedule row (or update one when "id" is sent)
 *   POST {action:"complete", schedule_id} -> mark that schedule completed today
 */

require_once __DIR__ . '/../config/bootstrap.php';

require_login();

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

try {
    $method = $_SERVER['REQUEST_METHOD'];

    // -----------------------------------------------------------------------
    // GET: return all schedules with today's completion status
    // -----------------------------------------------------------------------
    if ($method === 'GET') {
        $schedule = $pdo->query(
            "SELECT s.id, s.compartment, s.medication_name, s.dosage,
                    TIME_FORMAT(s.scheduled_time, '%H:%i:%s') AS scheduled_time,
                    s.active,
                    CASE WHEN EXISTS (
                        SELECT 1 FROM dose_events e
                        WHERE e.schedule_id = s.id
                          AND e.event_type = 'dose_completed'
                          AND e.device_id = 'dashboard'
                          AND DATE(e.created_at) = CURDATE()
                    ) THEN 'Completed' ELSE 'Pending' END AS status
             FROM medication_schedule s
             WHERE s.active = 1
             ORDER BY s.scheduled_time"
        )->fetchAll();

        echo json_encode(['ok' => true, 'schedule' => $schedule]);
        exit;
    }

    if ($method !== 'POST') {
        http_response_code(405);
        echo json_encode(['ok' => false, 'error' => 'Method not allowed']);
        exit;
    }

    verify_csrf();
    $body = json_input();

    // -----------------------------------------------------------------------
    // POST action=complete: remember that today's dose was taken
    // -----------------------------------------------------------------------
    if (($body['action'] ?? '') === 'complete') {
        $scheduleId = (int) ($body['schedule_id'] ?? 0);

        $row = $pdo->prepare('SELECT compartment, medication_name FROM medication_schedule WHERE id = ?');
        $row->execute([$scheduleId]);
        $schedule = $row->fetch();

        if (!$schedule) {
            http_response_code(404);
            echo json_encode(['ok' => false, 'error' => 'Schedule not found']);
            exit;
        }

        // Only record once per day per schedule.
        $exists = $pdo->prepare(
            "SELECT COUNT(*) FROM dose_events
             WHERE schedule_id = ? AND event_type = 'dose_completed'
               AND device_id = 'dashboard' AND DATE(created_at) = CURDATE()"
        );
        $exists->execute([$scheduleId]);

        if ((int) $exists->fetchColumn() === 0) {
            $insert = $pdo->prepare(
                "INSERT INTO dose_events (device_id, compartment, schedule_id, event_type, medication_name, details)
                 VALUES ('dashboard', ?, ?, 'dose_completed', ?, 'Marked complete by caregiver')"
            );
            $insert->execute([(int) $schedule['compartment'], $scheduleId, $schedule['medication_name']]);

            audit_log($pdo, (int) $_SESSION['user_id'], 'dose_completed', 'medication_schedule', (string) $scheduleId, [
                'compartment'     => (int) $schedule['compartment'],
                'medication_name' => $schedule['medication_name'],
            ]);
        }

        echo json_encode(['ok' => true, 'message' => 'Dose marked complete']);
        exit;
    }

    // -----------------------------------------------------------------------
    // POST: validate input
    // -----------------------------------------------------------------------
    $id          = (int) ($body['id'] ?? 0);
    $compartment = (int) ($body['compartment'] ?? 0);
    $name        = trim((string) ($body['medication_name'] ?? ''));
    $dosage      = trim((string) ($body['dosage'] ?? ''));
    $time        = (string) ($body['scheduled_time'] ?? '');

    $validTime = preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d(?::[0-5]\d)?$/', $time) === 1;

    $isValid = $compartment >= 1 && $compartment <= 3
        && $name !== '' && strlen($name) <= 120
        && $dosage !== '' && strlen($dosage) <= 80
        && $validTime;

    if (!$isValid) {
        http_response_code(422);
        echo json_encode(['ok' => false, 'error' => 'Invalid medication schedule data']);
        exit;
    }

    if (strlen($time) === 5) {
        $time .= ':00';
    }

    // -----------------------------------------------------------------------
    // POST: add a new schedule row, or update one when an id is given
    // -----------------------------------------------------------------------
    if ($id > 0) {
        $save = $pdo->prepare(
            'UPDATE medication_schedule
             SET compartment = ?, medication_name = ?, dosage = ?, scheduled_time = ?, active = 1
             WHERE id = ?'
        );
        $save->execute([$compartment, $name, $dosage, $time, $id]);
        $scheduleId = $id;
    } else {
        $save = $pdo->prepare(
            'INSERT INTO medication_schedule (compartment, medication_name, dosage, scheduled_time, active)
             VALUES (?, ?, ?, ?, 1)'
        );
        $save->execute([$compartment, $name, $dosage, $time]);
        $scheduleId = (int) $pdo->lastInsertId();
    }

    audit_log($pdo, (int) $_SESSION['user_id'], 'schedule_saved', 'medication_schedule', (string) $scheduleId, [
        'compartment'     => $compartment,
        'medication_name' => $name,
        'scheduled_time'  => $time,
    ]);

    echo json_encode(['ok' => true, 'message' => 'Schedule saved', 'id' => $scheduleId]);
} catch (Throwable $e) {
    error_log('MediTube schedule API: ' . $e->getMessage());
    http_response_code(500);
    echo json_encode(['ok' => false, 'error' => 'Unable to save schedule']);
}