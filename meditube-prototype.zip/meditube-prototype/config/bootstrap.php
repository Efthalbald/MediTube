<?php

declare(strict_types=1);

/**
 * Shared bootstrap: session setup, security headers, database connection
 * and small helpers (login guard, CSRF, JSON body) used across the app.
 */

// ---------------------------------------------------------------------------
// Session
// ---------------------------------------------------------------------------

$https = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';

session_name('MEDITUBESESSID');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'secure'   => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// ---------------------------------------------------------------------------
// Security headers
// ---------------------------------------------------------------------------

header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: strict-origin-when-cross-origin');
header('X-Frame-Options: DENY');
header('Permissions-Policy: camera=(self), microphone=(), geolocation=()');

// ---------------------------------------------------------------------------
// Database
// ---------------------------------------------------------------------------

require_once __DIR__ . '/database.php';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Send a JSON response with the given status code and stop the script.
 */
function json_response(array $payload, int $status = 200): never
{
    http_response_code($status);
    header('Content-Type: application/json');
    echo json_encode($payload);
    exit;
}

/**
 * Redirect guests to the login page (or return 401 JSON for API calls).
 */
function require_login(): void
{
    if (!empty($_SESSION['user_id'])) {
        return;
    }

    $isApiRequest = str_contains($_SERVER['REQUEST_URI'] ?? '', '/api/');

    if ($isApiRequest) {
        json_response(['ok' => false, 'error' => 'Authentication required'], 401);
    }

    header('Location: login.php');
    exit;
}

/**
 * Return the CSRF token for this session, creating one if needed.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf'];
}

/**
 * Reject the request unless it carries a valid CSRF token.
 * The token may come from the X-CSRF-Token header or a "csrf" POST field.
 */
function verify_csrf(): void
{
    $token = $_SERVER['HTTP_X_CSRF_TOKEN'] ?? ($_POST['csrf'] ?? '');

    if (!$token || !hash_equals($_SESSION['csrf'] ?? '', $token)) {
        json_response(['ok' => false, 'error' => 'Session token expired. Refresh and try again.'], 419);
    }
}

/**
 * Decode the JSON request body into an array (empty array if invalid).
 */
function json_input(): array
{
    $decoded = json_decode(file_get_contents('php://input'), true);

    return is_array($decoded) ? $decoded : [];
}

/**
 * Write an entry to the audit log.
 */
function audit_log(PDO $pdo, ?int $userId, string $action, ?string $entityType = null, ?string $entityId = null, ?array $details = null): void
{
    $statement = $pdo->prepare(
        'INSERT INTO audit_log (user_id, action, entity_type, entity_id, details_json, ip_address)
         VALUES (?, ?, ?, ?, ?, ?)'
    );

    $statement->execute([
        $userId,
        $action,
        $entityType,
        $entityId,
        $details === null ? null : json_encode($details),
        $_SERVER['REMOTE_ADDR'] ?? null,
    ]);
}
