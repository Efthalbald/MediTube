<?php

declare(strict_types=1);

/**
 * Database connection.
 *
 * Credentials are read from environment variables so no secrets live in the
 * source code. The defaults below are meant for a local XAMPP setup only.
 */

$DB_HOST = getenv('MEDITUBE_DB_HOST') ?: '127.0.0.1';
$DB_NAME = getenv('MEDITUBE_DB_NAME') ?: 'meditube_db';
$DB_USER = getenv('MEDITUBE_DB_USER') ?: 'root';
$DB_PASS = getenv('MEDITUBE_DB_PASS') !== false ? getenv('MEDITUBE_DB_PASS') : '';

$dsn = "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4";

$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

try {
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, $options);
} catch (PDOException $e) {
    error_log('MediTube database connection failed: ' . $e->getMessage());
    http_response_code(503);

    if (PHP_SAPI !== 'cli') {
        header('Content-Type: text/html; charset=utf-8');
        echo '<h1>MediTube is not configured</h1>';
        echo '<p>Check database credentials and import database/meditube_db.sql. See docs/DEPLOYMENT.md.</p>';
    }

    exit;
}
